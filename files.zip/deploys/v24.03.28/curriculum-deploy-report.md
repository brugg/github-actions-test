- [ ] ap-computer-science-a                                        COURSE=ap-computer-science-a 
  * [ ] course.json
  * [ ] addition-problem                                             c0332df2-1565-4a63-bd3a-0c77f455d033
  * [ ] alien-language-translator                                    4723a8a3-9ed8-40b8-a932-ba7a7a80d84b
  * [ ] animal-friends-part-a                                        46e1ab03-20cb-4283-8d2f-cc0c22ae3eb1
  * [ ] animal-friends-part-b                                        b4c45fe9-68db-4f71-89e0-622910884913
  * [ ] battery-charger-part-a                                       b27381d9-0e06-4e96-8c95-1206e356e7c0
  * [ ] battery-charger-part-b                                       e47e74d4-71b8-4b7d-8bc2-accd9d4f5b6a
  * [ ] blabberbot-activity-1                                        2ed2cbd8-d85b-42cf-9971-f847a7847a22
  * [ ] blabberbot-activity-2                                        d28abb06-a4a2-4094-8bf0-770409b1d236
  * [ ] blabberbot-activity-3                                        fb4f94b7-fde7-4c49-b1b8-38f740c39741
  * [ ] divide-and-conquer                                           9d8993ea-263e-4325-be2b-b38b45315283
  * [ ] edit-that-clause-part-a                                      366e9113-d49e-407e-bdf0-b9fdce14c7a9
  * [ ] edit-that-clause-part-b                                      d020b667-1419-4070-a618-ec470249c3f2
  * [ ] four-in-a-row                                                94c846d2-36b5-11ec-8d3d-0242ac130003
  * [ ] full-course-meal                                             e5ce7f10-3d81-11ec-9bbc-0242ac130002
  * [ ] horse-stable-part-a                                          7d09231c-9f51-4acf-829e-8fdb5fc89363
  * [ ] horse-stable-part-b                                          9bf53fb5-316b-43b1-9f6c-cdeebaf75c61
  * [ ] horse-stable-part-c                                          812519de-599a-40bf-b2e5-af74e1b575c9
  * [ ] i-will-survive                                               e1029215-8bf6-4d4e-a212-9eb293f64a06
  * [ ] information-transformation-activity                          1269e10c-c85a-4ad3-9b6b-62c5e4cf9637
  * [ ] lets-play-cards-activity                                     2d7e0409-7136-4331-9c03-593d171ea2da
  * [ ] lets-split-it                                                df564ff0-9b6f-4626-ba32-86cdc3ba56ff
  * [ ] level-1-exam                                                 2ab050bb-c06f-48e7-b979-09e6c373bf56
  * [ ] level-1-progress-check                                       1af485f3-b06f-4a6d-ae5f-4ee5590fa8cb
  * [ ] level-2-exam                                                 b60a7a2f-855b-4fbd-b3e9-84a495d2d6c7
  * [ ] level-2-progress-check                                       71964f2f-49a9-4f47-9918-66cb74e44af8
  * [ ] level-3-exam                                                 b3cd8810-2aaa-11ec-8d3d-0242ac130003
  * [ ] level-3-progress-check                                       e9c044b2-e10a-47e8-b0ab-6020c5bc4907
  * [ ] level-4-exam                                                 4a97160c-2ab1-11ec-8d3d-0242ac130003
  * [ ] level-4-progress-check                                       18e5a709-3edc-48e9-943d-7cedea87f309
  * [ ] level-5-exam                                                 3ee085a1-8c97-4396-aedb-f8bfd64d6a1b
  * [ ] level-5-progress-check                                       5cb9e475-9f86-49b8-b6f1-0ece74a01c4f
  * [ ] level-6-exam                                                 ebade467-85b8-4f7e-937c-19fb38ebafb8
  * [ ] level-6-progress-check                                       a63ec35b-b8a1-4191-b101-ff2e90601b18
  * [ ] level-7-exam                                                 3d488c2a-80ad-4dcd-8a3e-29a2c48866fc
  * [ ] level-7-progress-check                                       336a2bc8-7ea6-4177-bbf1-9820d762be54
  * [ ] level-8-exam                                                 cc20cf13-b687-408d-a1c3-dd6dcc59ba1c (NOT WIRED INTO COURSE)
  * [ ] level-8-progress-check                                       33d66456-8782-4c27-abe4-82bee27751ce
  * [ ] media-marathon-tracker                                       fb44ee01-d8f5-41ca-9d0d-8380d9e440fb
  * [ ] murder-mystery-party                                         589c30e2-2d9d-43fc-a0cc-05fa9cf76768
  * [ ] my-favorite-people                                           b295ac14-4da9-45d6-87fe-d3ee40a4dd76
  * [ ] name-my-tunes                                                04909976-842b-4244-b98d-202f17a5b0b8
  * [ ] online-shopping                                              0f6baa62-27d1-11ec-9621-0242ac130002
  * [ ] open-for-business                                            f9c5b315-20a8-444a-b62c-a149b958f3ce
  * [ ] picture-switch-activity-1                                    e27948f8-a052-46ad-97c1-1bd316be72c5
  * [ ] picture-switch-activity-2                                    78b01652-4d2f-4eb4-8cd5-e9d990c885c0
  * [ ] ready-player-num-part-a                                      9411ed0a-0ee5-4513-ba01-dcfb9578b470
  * [ ] ready-player-num-part-b                                      06bbf969-bb34-4fe3-bce0-ddeaf6131e92
  * [ ] shades-of-gray-part-a                                        740bbffa-a3f6-4da2-a300-d082ab5c8408
  * [ ] shades-of-gray-part-b                                        f1965a73-7358-4c0a-94a9-c19d359dae8a
  * [ ] social-media-explorer                                        d41f8718-270c-11ec-9621-0242ac130002
  * [ ] stack-the-deck                                               e7872262-326a-4584-a8cc-10f9f0e653c5
  * [ ] table-settings                                               0d6edc44-473d-11ec-81d3-0242ac130003
  * [ ] theater-tickets                                              34ed45a7-0f42-4696-86aa-b032a45860f7
  * [ ] town-square                                                  b8b19094-056a-4458-ab49-ffab45b95ff0
  * [ ] treasure-map                                                 705fb57f-9491-4252-bc42-86c21f078fd8
  * [ ] trivia-time                                                  68ed2ffa-02bd-46ce-b371-652248a6020e
  * [ ] typing-test                                                  1547a5b4-f412-4ccb-94c0-bdac32f7cac0
  * [ ] virtual-pet                                                  2a2ead69-2d63-4946-9b59-65d7847525b0
  * [ ] walk-through-history                                         d24fcd92-3267-11ec-8d3d-0242ac130003
  * [ ] wallpaper-design                                             3c1c69d8-badb-452b-b55c-f1b3a11c1f60
  * [ ] what-to-watch                                                521634af-0375-404d-aafa-ff8b8c426e0c
  * [ ] word-searcher                                                e801725a-3c24-11ec-b41c-3718bd661941
  * [ ] wordscapes-challenge                                         efff55dd-2881-4376-be14-26e906c5517a
- [ ] ap-computer-science-principles                               COURSE=ap-computer-science-principles 
  * [ ] course.json
  * [ ] a-voice-assistant-for-everyone                               ea7bced9-3be5-468e-9318-8fee69ba43ea
  * [ ] abstraction                                                  70a8539e-d1b3-4537-b92c-4f6c0df2aec7
  * [ ] algorithms                                                   ace86fa2-a5dd-468e-a941-6cbd5a565a86
  * [ ] binary-search                                                9c497cb0-bda2-4eb6-9cea-bb19309243bc
  * [ ] binary-world-science-museum-day-1                            cd7f904a-de5a-4593-b114-7b7a8b100fa2
  * [ ] binary-world-science-museum-day-2                            d7184bd7-55c9-4a24-9e15-88f5c6df6726
  * [ ] brainstorming-for-create-pt                                  562a3300-8131-4b5f-94eb-ccf255becfb0
  * [ ] carnival-game                                                22265acd-9831-4c0c-9d7c-c31e5633d602
  * [ ] clubhouse                                                    bf0737b4-28e6-4061-be8d-7adab3983363
  * [ ] compucon                                                     2d71f3e5-94cb-4978-bc42-6ed8cf7dd9b5
  * [ ] conditionals                                                 4e4c143d-b623-49fe-ba89-2ebcb3a44b5d
  * [ ] costume-shopping                                             043a87c9-1513-4c06-89a6-4bb76b3eb411
  * [ ] create-task                                                  07d6cbed-b175-46f5-b0fe-83f16c59cc1f
  * [ ] digital-detectives                                           672c1ca9-0f94-4bb8-9913-717c2e4edcf9
  * [ ] dj-turn-it-up                                                58b2df06-0e48-4844-958f-f85c197c47c7
  * [ ] going-for-gold                                               2a4a5a34-638e-49a7-95fb-36f8317ca8d0
  * [ ] heat-waves                                                   6467d8f0-753d-4603-86f9-07de6d914785
  * [ ] innovations-exploration                                      51060c0a-b8c3-4d93-9eb8-1cb0e7d865c3
  * [ ] intro-to-cybersecurity                                       cbe392f6-1539-4151-aa7b-172ec0ce4601
  * [ ] intro-to-the-internet                                        a9a04cba-c5f3-44d3-bce8-51a6fcb2ea16
  * [ ] iteration-and-functions                                      f3721667-ecc9-48d8-8ce9-d340d66c3552
  * [ ] level-1-end-exam                                             51b4d316-160c-4bac-b7f5-54de5df13f5b (NOT WIRED INTO COURSE)
  * [ ] level-1-exam                                                 fb24f71e-b9f1-4e36-b087-0d1d2062802f
  * [ ] level-1-mid-exam                                             d96cb315-1ed4-4636-9f7d-6f94942080da (NOT WIRED INTO COURSE)
  * [ ] level-2-end-exam                                             5a2ba9af-3805-4c49-841f-278fa7adb8cc
  * [ ] level-2-exam                                                 a5f05d24-1d00-45bb-b642-df6521645b3b
  * [ ] level-2-mid-exam                                             60aa400e-5644-4d44-9dca-cb4f18a2a0f1 (NOT WIRED INTO COURSE)
  * [ ] level-3-end-exam                                             6da637db-8945-4083-9504-4c038b4f104c
  * [ ] level-3-exam                                                 2e277dd3-9667-416c-84ae-a0080de337e2
  * [ ] level-3-mid-exam                                             efcd1e76-17ec-420e-9cb9-91b090ca99cf
  * [ ] level-7-end-exam                                             6a8475b0-50d0-4d22-8ec5-b51c4142cc16
  * [ ] level-7-mid-exam                                             04f0d3cf-4e5e-4a30-a17e-ef8effab72dc
  * [ ] linear-search                                                15b4d87a-4630-4845-b296-173d7afd8d9d
  * [ ] lists                                                        7cdb9df9-bf81-4dee-a930-967e75397c6f
  * [ ] living-in-digital-times                                      29cb712c-9cee-4e15-8a31-b68df965886f
  * [ ] mail-sorting-mayhem                                          fc5ede36-8c35-413e-b4dc-36a0caca0bfc
  * [ ] mission-space                                                b811da9d-26a6-484e-919d-cd8c4024a676 (NOT WIRED INTO COURSE)
  * [ ] my-future-goals                                              011a0c26-f384-4a65-9bd7-eee6daf02350
  * [ ] obstacle-course                                              77d57595-e442-4872-b7f3-fadf6b32acd6
  * [ ] paint-shop                                                   18cd799f-a9f3-43b6-9588-fcb6cb2b89a0 (NOT WIRED INTO COURSE)
  * [ ] pet-store                                                    9f15b121-0191-4762-93db-12cb41e2f6c7
  * [ ] practicing-for-the-create-pt                                 798a4ec0-3ee3-4f1a-b50f-f050fc067502
  * [ ] preparing-for-the-student-exam-reference-sheet               9f1fd48b-098a-46e4-bbe0-ca73e679484c
  * [ ] random-racing                                                47d2d375-9edb-4214-9bce-f82751ea235d
  * [ ] reviewing-the-create-pt-learning-objectives                  3316cf50-7348-45dd-a170-b549c2c2795c
  * [ ] robot-game                                                   db3afc3b-923a-4bfb-b207-5c427e2a08ba
  * [ ] robot-game-creator                                           57f7ddfe-b6cd-481c-889b-9cda2035dd40
  * [ ] secret-maze                                                  0bd86761-ca7c-4b8a-b096-cee0ebf6d6c9
  * [ ] spot-the-bot                                                 4bba3b5f-d1a8-486f-be58-adcc3bb9c04c
  * [ ] tiny-tasks                                                   8806ab1d-38da-4638-be52-2ec9697f38db
  * [ ] tutorial-mouse                                               55fbe7e2-8faa-4e99-a95d-6d7355ff7ab0
  * [ ] tutorial-touchpad                                            b766608c-1c26-4379-9dd2-57ed5487e354 (NOT WIRED INTO COURSE)
  * [ ] understanding-the-create-pt                                  75ae6c06-cfcc-4793-94c5-d7461678351c
  * [ ] underwater-research-quest                                    753a291d-d438-46d8-a396-5953f9d27de7
  * [ ] variables-and-data-types                                     8615297b-37e1-47df-bb67-c43124a76cdc
- [ ] cybersecurity                                                COURSE=cybersecurity 
  * [ ] course.json
  * [ ] under-construction                                           b224b0e5-bdf1-47e3-bf9a-e7a28b41b336
- [ ] data-science-and-ai-a                                        COURSE=data-science-and-ai-a 
  * [ ] course.json
  * [ ] are-you-a-robot                                              d87b389e-762a-47d6-94d7-3e474bdaa892
  * [ ] ask-the-expert                                               5610ded3-8e29-49d7-ae1a-d47909b53044
  * [ ] big-debut                                                    8e2b5ea3-dfc6-46d4-b951-59ec98ae6762
  * [ ] bike-share-planning                                          753461be-8908-449b-8c07-6a090ca997b8
  * [ ] build-a-twitter-bot                                          236fdb52-1d51-49c8-9132-105fb1768c83
  * [ ] business-founder                                             9916ee8a-b1ba-490f-8ef4-72cfdc2f4631
  * [ ] can-i-take-your-order                                        c1d672bf-6689-41cd-a93e-82e30758b419
  * [ ] collaborative-sentence                                       49ac17f4-3ca9-449b-be04-b6fdd7264cd2
  * [ ] color-challenge                                              4aa75265-37ce-497c-9726-5524ffeeb4d7
  * [ ] compromised-data                                             54c03639-75fa-4434-9213-bfd627e21629
  * [ ] covid-cautious                                               030f3df8-415e-4a30-b2e7-821251576565
  * [ ] dance-creator                                                990ff55c-b388-4e9d-8c4c-2fcdcbf506d7
  * [ ] detective                                                    bb445c71-817f-4009-bc37-4999b70803c6
  * [ ] disaster                                                     51f1165c-49f2-4ba3-b2c6-98b0871f5f85
  * [ ] dream-team                                                   80082131-1bb3-4217-a75f-f5cb962c91df
  * [ ] emoji-diet                                                   1e7eb0e9-cf5e-4044-ab10-37655a1c15a1
  * [ ] font-machine                                                 a6012f72-1c05-42ab-9526-3988644a2fe2
  * [ ] fortune-teller                                               f2680cfb-dcf9-4a75-ab00-712d8a3933b3
  * [ ] gabby-the-chatbot                                            bd62cb3d-658e-49d2-a5f7-46590b64be6d
  * [ ] get-off-the-road                                             bc95d673-60b3-437f-bf8b-9aaada62a625
  * [ ] graduation-goals                                             48010014-92ce-4c3f-8ff7-d8fdd59db07a
  * [ ] grid-maze                                                    c0a35e56-a833-4c44-a8b3-6ffd55116901
  * [ ] highway-generator                                            05ffab21-e1d8-421c-8828-2fa90b2e3e22
  * [ ] horoscope                                                    cdad272c-a89e-4e1d-b0c3-e9d9bac9277d
  * [ ] i-want-it-i-bought-it                                        aa58a196-e385-4b90-94c7-71fb247abb6e
  * [ ] interactive-story                                            2f568cba-d57b-466e-8afe-30115fa7a3f6
  * [ ] lightning-round                                              70613bd3-56df-465e-bcca-c35a36784343
  * [ ] math-trainer                                                 3f372f57-acdd-48f3-b7c8-475b0b0296ee
  * [ ] media-recommender                                            3e0bd8b2-358e-464b-aee1-b9f63d545fcc
  * [ ] memory-game                                                  9a5b07d5-3f4c-45be-9e31-0b14afa9f7b3
  * [ ] mental-health-monitor                                        a2170291-8008-4efe-b5fd-46b03b358020
  * [ ] movie-search                                                 85a415c3-7b6d-4935-8a6c-67bce88a7fac
  * [ ] movie-trailer                                                56b1d913-183f-47ad-b5f3-64af67167d4a
  * [ ] my-name-is                                                   4f19ee8b-321f-4835-9563-6fe81b5d08f3
  * [ ] number-trick                                                 083568da-8c6d-4669-901e-6575e787b60d
  * [ ] out-of-this-world                                            6ef2640c-2398-4f59-b714-4cbda3b6cf06
  * [ ] password-hacker                                              f41c05e0-1b75-40b4-8784-67de4d39c273
  * [ ] photo-classifier                                             ac1c9a53-e22b-416c-85e0-71cd2443caa0
  * [ ] plagiarism-detector                                          eefac811-49b0-421d-a194-b3ff5c8ee407
  * [ ] quote-collector                                              084627a1-de81-4026-a0d8-36246ce7412b
  * [ ] rewriter                                                     4f3ae43e-6184-4f02-9b59-fbc830356386
  * [ ] riddle-keeper                                                0b0dd466-f492-4813-8a92-bac83514bf9a
  * [ ] rock-paper-scissors                                          44d73052-c031-4f38-bc11-944989cf72ef
  * [ ] secret-word                                                  72ef4305-5f4d-42bf-abc4-44ae18525d81
  * [ ] snack-shack                                                  5d9228da-41bd-4e12-85b3-a53cdf5531e2
  * [ ] speaking-style                                               8ebd27f5-3eef-4bb4-9293-a6be71fd146e
  * [ ] special-request                                              d7802374-1a47-4af6-a101-e45b8ba94856
  * [ ] sports-reporter                                              ec08d1c6-24ed-400c-946a-33c49e764d78
  * [ ] superfan                                                     fbc3b93b-286c-4735-8caa-71f6a2531851
  * [ ] text-adventure                                               fafbdff1-c657-47e5-a7dd-379b378b52a6
  * [ ] the-goat                                                     4115c116-7f11-4452-a732-345c4767d5bd
  * [ ] the-great-race                                               2ff035f7-7925-41cb-af3a-7304ac1617b3
  * [ ] the-house-always-wins                                        fd08bd44-18b7-4121-8633-344422690c61
  * [ ] trick-challenge                                              51596353-6651-45dc-a1b8-940324fcfb8d
  * [ ] trivia-countdown                                             638dc37e-2d1a-4953-842c-d28ae23a2434
  * [ ] tv-show-analyzer                                             855128bc-a06a-42fd-8b87-8471ff43c555
  * [ ] twin-counties                                                809e754c-e0c0-4105-966a-34857f694882
  * [ ] user-namer                                                   710186c9-e51d-404e-b937-49db479b19a7
  * [ ] video-prompter                                               43187fbd-8e71-47e0-b120-425fc02c3e15
  * [ ] wizard-battle                                                595aa73a-81cf-44b3-89ba-5e51c29f584c
- [ ] data-science-and-ai-a-practice-problems                      COURSE=data-science-and-ai-a-practice-problems 
  * [ ] course.json
  * [ ] 1.1_fortune-teller-practice-problem-1                        0eecce6b-a38a-494b-bb74-215121d5d491
  * [ ] 1.1_fortune-teller-practice-problem-2                        c5f9fd8c-d16b-48fd-8691-3372b64fa3d0
  * [ ] 1.1_fortune-teller-practice-problem-3                        91a36ca7-9e20-4aaa-a3f5-7a862061ebfa
  * [ ] 1.1_fortune-teller-practice-problem-4                        4531c86d-dd04-4e6d-8e64-7da010c0be1f
  * [ ] 1.1_fortune-teller-practice-problem-5                        30dbef1c-41fe-429f-b49e-c5119f1ec115
  * [ ] 1.1_fortune-teller-practice-problem-6                        b0811e63-0367-42db-b843-82d8743da1ac
  * [ ] 1.1_fortune-teller-practice-problem-7                        ff1dc84a-3961-4d5d-9b5b-2eeea0ae17cf
  * [ ] 1.1_fortune-teller-practice-problem-8                        df6596b8-a086-4f38-98eb-0571784dfaca
  * [ ] 1.2_interactive-story-practice-problem-1                     6256ded7-a7fc-4135-9029-a00a5bfcfa5d
  * [ ] 1.2_interactive-story-practice-problem-2                     763875ef-170b-4d1b-be73-48be7cabd15f
  * [ ] 1.2_interactive-story-practice-problem-3                     d6214594-9258-412e-8924-8aaa3cdb14b4
  * [ ] 1.2_interactive-story-practice-problem-4                     dfd3c827-f371-48e5-82f4-758da8bc7fd2
  * [ ] 1.2_interactive-story-practice-problem-5                     a55298b3-a9ec-4d05-af43-30479fa7e967
  * [ ] 1.2_interactive-story-practice-problem-6                     b8dc492c-d552-4b74-828d-85a241e09a55
  * [ ] 1.2_interactive-story-practice-problem-7                     355d98b5-8617-4d1f-8dd7-d7ad85dcd313
  * [ ] 1.2_interactive-story-practice-problem-8                     3a0cd308-09c0-4f5a-8d36-1cd89f111547
  * [ ] 1.3_user-namer-practice-problem-1                            2d5a02bf-4841-45da-84c9-385448129d90
  * [ ] 1.3_user-namer-practice-problem-2                            e36697ca-0468-42e4-a7d9-34bddf289e76
  * [ ] 1.3_user-namer-practice-problem-3                            fa25dc62-23d9-41e6-a52e-6ee34257c6f6
  * [ ] 1.3_user-namer-practice-problem-4                            24d4995f-8961-4d63-adf7-e0705ba7f9ee
  * [ ] 1.3_user-namer-practice-problem-5                            6dfff8b3-a907-4a51-95e6-ed86ef25b84e
  * [ ] 1.3_user-namer-practice-problem-6                            c84815a7-d4f9-41cf-b6b2-5c87d28cb317
  * [ ] 1.3_user-namer-practice-problem-7                            d2e087bb-2ac9-4545-9ec6-d2e9c336d3e3
  * [ ] 1.3_user-namer-practice-problem-8                            912cddc3-db10-46e6-ae52-86f803ef3dde
  * [ ] 1.4_independent-projects-practice-problem-1                  70d41473-1da3-4940-a314-7ebef254e0db
  * [ ] 1.4_independent-projects-practice-problem-10                 953b6870-62e7-4710-8334-06c35fb3a227
  * [ ] 1.4_independent-projects-practice-problem-11                 edea9ae8-73cd-4b28-9b2b-2db3cdebddb5
  * [ ] 1.4_independent-projects-practice-problem-12                 805cf28c-d48f-4f03-be03-9895914f3f95
  * [ ] 1.4_independent-projects-practice-problem-13                 3c1e0a9f-ef84-4423-80a6-38fc9d635864
  * [ ] 1.4_independent-projects-practice-problem-14                 25c65a77-9932-46e4-aa6a-e0e38c50f643
  * [ ] 1.4_independent-projects-practice-problem-15                 95490b8f-5234-4b79-8c27-5788b1e1a9a7
  * [ ] 1.4_independent-projects-practice-problem-16                 3789c051-af4e-4a69-b758-c7fc6fe0301b
  * [ ] 1.4_independent-projects-practice-problem-17                 4822ef37-0ec5-4ba1-96f3-f61d0751f56e
  * [ ] 1.4_independent-projects-practice-problem-18                 f1b91d3f-f94d-428e-89e2-fb9b8b38630e
  * [ ] 1.4_independent-projects-practice-problem-19                 5aa1a7b5-a3a2-41f8-8a7b-928d751a91a3
  * [ ] 1.4_independent-projects-practice-problem-2                  62788229-1191-41da-9730-bac48b2dbf9a
  * [ ] 1.4_independent-projects-practice-problem-20                 34943943-480d-400d-87a5-9c4a1e09a1d7
  * [ ] 1.4_independent-projects-practice-problem-21                 33f281c6-608f-4e55-ac0f-d98a24b7fae1
  * [ ] 1.4_independent-projects-practice-problem-22                 880b78de-e0c7-4c7d-9eef-4f5a6802cf2a
  * [ ] 1.4_independent-projects-practice-problem-23                 f6581c38-2cd8-473c-a3a8-289b0460c0c3
  * [ ] 1.4_independent-projects-practice-problem-24                 916d0ad9-25b9-4488-a26d-d17f15baa527
  * [ ] 1.4_independent-projects-practice-problem-3                  61c7cfa4-97c3-4318-89fe-2aad16feccce
  * [ ] 1.4_independent-projects-practice-problem-4                  e7616d1b-31f0-41d0-a4e4-3f38aec571d2
  * [ ] 1.4_independent-projects-practice-problem-5                  5f225dee-f16a-4ad7-bb96-ad133d6518c4
  * [ ] 1.4_independent-projects-practice-problem-6                  34ec7678-4a5f-421c-bb67-5daf2d6eccce
  * [ ] 1.4_independent-projects-practice-problem-7                  6eca7ab7-8281-4232-8223-54ddd9d55bde
  * [ ] 1.4_independent-projects-practice-problem-8                  bce6a46d-8dc5-4bbd-8d39-f432f3ec2d40
  * [ ] 1.4_independent-projects-practice-problem-9                  7f71a007-b0e9-4051-8c9c-ab9eb50f5f24
  * [ ] 2.1_can-i-take-your-order-practice-problem-1                 314b7e88-6e7a-442e-a5ff-735235bed743
  * [ ] 2.1_can-i-take-your-order-practice-problem-2                 079e6e4c-1c64-4aff-8bba-208f12e62314
  * [ ] 2.1_can-i-take-your-order-practice-problem-3                 155b1faf-5c11-4d33-9467-14d4f7db1848
  * [ ] 2.1_can-i-take-your-order-practice-problem-4                 1600b42e-f3da-436d-8982-9fb929c4509c
  * [ ] 2.1_can-i-take-your-order-practice-problem-5                 d9f6599a-0c49-4dca-a8c2-0bf4792f75cb
  * [ ] 2.1_can-i-take-your-order-practice-problem-6                 2370fc5f-8b11-405b-9884-a8224df064e9
  * [ ] 2.1_can-i-take-your-order-practice-problem-7                 098771aa-7901-4285-9175-da75d61e451f
  * [ ] 2.1_can-i-take-your-order-practice-problem-8                 05421fcc-0de5-472e-9729-572fcde3ac30
  * [ ] 2.2_the-goat-practice-problem-1                              e5a71767-1579-4561-908f-ef6b26ae2187
  * [ ] 2.2_the-goat-practice-problem-2                              2716f3ea-60d9-42f8-922d-38a28a42dbd6
  * [ ] 2.2_the-goat-practice-problem-3                              d90f9a01-b050-4609-b16a-f578214e760e
  * [ ] 2.2_the-goat-practice-problem-4                              570e1255-d175-41f1-9213-33235bce591c
  * [ ] 2.2_the-goat-practice-problem-5                              ac867d76-8dbd-44bd-aa04-031e7947e0b5
  * [ ] 2.2_the-goat-practice-problem-6                              73db0182-a912-4c01-8f60-03a984657e06
  * [ ] 2.2_the-goat-practice-problem-7                              8bb2577f-5bf7-43da-a6ed-aaa513962f21
  * [ ] 2.2_the-goat-practice-problem-8                              59b346d9-3b96-4afd-9b6f-d7bc2ed0bb6e
  * [ ] 2.3_the-great-race-practice-problem-1                        f1dc017a-74d4-4aaf-b2fb-45ad825a5348
  * [ ] 2.3_the-great-race-practice-problem-2                        990142ee-84ed-4c68-8c84-629211e929e8
  * [ ] 2.3_the-great-race-practice-problem-3                        52821e99-7148-4c50-8726-94e657778d8d
  * [ ] 2.3_the-great-race-practice-problem-4                        c9e16095-0f8f-424b-a5e1-f3720d4b28c8
  * [ ] 2.3_the-great-race-practice-problem-5                        cdf0de39-c8a4-4fc4-9def-efb7b8c66be9
  * [ ] 2.3_the-great-race-practice-problem-6                        a90dffbe-2436-45ce-93eb-767958e9780b
  * [ ] 2.3_the-great-race-practice-problem-7                        eabeb8f9-c53d-4af5-ad6e-c908d4caa5ad
  * [ ] 2.3_the-great-race-practice-problem-8                        310fb65b-91e9-4026-828c-73a10bfee334
  * [ ] gabby-the-chatbot-practice-problem-1                         da60ef26-942c-4084-90ef-b7cf720e739e
  * [ ] gabby-the-chatbot-practice-problem-2                         4653e0e7-c6a2-452a-b9c1-a60efa7b0aae
  * [ ] gabby-the-chatbot-practice-problem-3                         ce2faa03-764e-40ed-bdc4-372303e67a0e
  * [ ] gabby-the-chatbot-practice-problem-4                         81dd4926-0f2d-46a7-a253-db010fb3cd45
  * [ ] gabby-the-chatbot-practice-problem-5                         98f63d8c-2a85-42bc-b052-0f8b34ed1bd8
  * [ ] gabby-the-chatbot-practice-problem-6                         fa3e2d8a-c235-4412-9a01-f2f317bee3e0
  * [ ] gabby-the-chatbot-practice-problem-7                         105d19a0-50a0-42a8-a700-c3abfc1a933f
  * [ ] gabby-the-chatbot-practice-problem-8                         0a7b24d2-cead-415d-9a53-01496578ac03
  * [ ] horoscope-practice-problem-1                                 641d2294-aa87-4493-8650-1e2922957a8c
  * [ ] horoscope-practice-problem-2                                 0abcab88-5eda-4c76-9be6-308cceef1c58
  * [ ] horoscope-practice-problem-3                                 09c627dd-2763-467e-a919-ef917baaa8d0
  * [ ] horoscope-practice-problem-4                                 af1154ea-0a87-454f-a650-d5ee37ad1c0a
  * [ ] horoscope-practice-problem-5                                 344b57e4-9e54-4ffd-a6fe-ad28dfd9f817
  * [ ] horoscope-practice-problem-6                                 81c0e659-af0f-48bd-9f66-29e7526525e2
  * [ ] horoscope-practice-problem-7                                 c6cf4104-695c-4d6d-84b4-6094ca4e6932
  * [ ] horoscope-practice-problem-8                                 e370d06e-29ae-46d9-ba50-0683184dceed
  * [ ] level-4-independent-projects-practice-problem-1              f60799ac-db3c-4ac2-97f9-0f9dbfcc060f
  * [ ] level-4-independent-projects-practice-problem-10             725c205e-b1d0-4280-9739-afca3156e940
  * [ ] level-4-independent-projects-practice-problem-11             4d82820b-ef79-4eb3-b885-5627166f3b75
  * [ ] level-4-independent-projects-practice-problem-12             b7d497ef-8bb1-4825-80f9-50dd666e838b
  * [ ] level-4-independent-projects-practice-problem-13             4df55347-2c9a-4736-ae8d-e7f5c0f45c83
  * [ ] level-4-independent-projects-practice-problem-14             28787df7-150c-4a03-8af2-203dda9e1018
  * [ ] level-4-independent-projects-practice-problem-15             5c69ff76-d3ec-47aa-969a-34397fe2cb0b
  * [ ] level-4-independent-projects-practice-problem-16             8774745a-8f08-4dae-ae4c-83a8bcfa5d4a
  * [ ] level-4-independent-projects-practice-problem-17             857e7330-3cdf-4769-a4ee-4782d25809cc
  * [ ] level-4-independent-projects-practice-problem-18             311f7378-acfe-4998-8fba-8d19bf1f67a0
  * [ ] level-4-independent-projects-practice-problem-19             e02c0d7d-2556-4df9-b7c8-87d30152d527
  * [ ] level-4-independent-projects-practice-problem-2              0c357fcd-13b6-433f-994b-39edda4bcce4
  * [ ] level-4-independent-projects-practice-problem-20             f94cc453-c555-494f-93b2-8d72a9240733
  * [ ] level-4-independent-projects-practice-problem-21             c2e72bfd-f845-4d1b-b468-ba355bef7a06
  * [ ] level-4-independent-projects-practice-problem-22             b5bc0192-f2ab-4b05-bc4d-0bb06a88305e
  * [ ] level-4-independent-projects-practice-problem-23             07f3bdac-9541-45f6-95fd-0ee2f2397179
  * [ ] level-4-independent-projects-practice-problem-24             01c0ee3b-ba41-4753-a6db-15c27b9586f5
  * [ ] level-4-independent-projects-practice-problem-3              dc0c3956-6a00-4468-a410-3f6bfeec12ce
  * [ ] level-4-independent-projects-practice-problem-4              1043ecf1-3b46-44d5-b306-6aad9a0e1850
  * [ ] level-4-independent-projects-practice-problem-5              580250a8-cad0-497e-91ef-4f18ff71b435
  * [ ] level-4-independent-projects-practice-problem-6              c3b791d3-e203-47b3-a42d-f94335df730e
  * [ ] level-4-independent-projects-practice-problem-7              16c53ed8-2ab6-44e8-9e94-317d84b5cf53
  * [ ] level-4-independent-projects-practice-problem-8              a88cbab3-2837-4cba-89f3-209c8928be5c
  * [ ] level-4-independent-projects-practice-problem-9              dcc99d1b-36c4-4c7e-9964-757f11e5ad61
  * [ ] snack-shack-practice-problem-1                               8ccb0f29-bd28-4158-894d-7db2dac6338e
  * [ ] snack-shack-practice-problem-2                               a5d4d799-2065-421d-ad48-721dfe643b62
  * [ ] snack-shack-practice-problem-3                               2ed9f155-d42d-42dc-8465-281f13e471a4
  * [ ] snack-shack-practice-problem-4                               7c711414-6097-4415-afa6-e63b2e02846d
  * [ ] snack-shack-practice-problem-5                               3d046641-1e79-4402-bb8f-aeb27c61ffc8
  * [ ] snack-shack-practice-problem-6                               c2a5a38f-940c-4b46-95e8-20bf7196f300
  * [ ] snack-shack-practice-problem-7                               16a676b0-85af-41fb-97c6-df9e431cf235
  * [ ] snack-shack-practice-problem-8                               861e6ca9-269b-403c-a19e-caf7f0f4ad64
  * [ ] special-request-practice-problem-1                           2840cf9d-81b3-493f-80b6-d4934a9b931d
  * [ ] special-request-practice-problem-2                           e0d13382-0ed6-4d35-9f73-ad201789b1b7
  * [ ] special-request-practice-problem-3                           23aa59f1-1714-41de-af8e-b6f045ade5f3
  * [ ] special-request-practice-problem-4                           4f38e04a-133f-4d0b-ac71-06edd6558a18
  * [ ] special-request-practice-problem-5                           869f240c-cb74-45aa-ad2e-0814c74a4ffb
  * [ ] special-request-practice-problem-6                           3ef5609c-54fc-49ef-a2ba-53403a132552
  * [ ] special-request-practice-problem-7                           a0c3ffe6-fab8-4ad3-95ac-7d54dad26b13
  * [ ] special-request-practice-problem-8                           e8b9ad24-794b-410d-8a3d-99aad88457a1
  * [ ] text-adventure-practice-problem-1                            7b92cf7e-01d9-4d13-b644-04a9159a859d
  * [ ] text-adventure-practice-problem-2                            b0ef18e9-028c-4304-8fab-0f1b8fca8b58
  * [ ] text-adventure-practice-problem-3                            84c156cc-ce8e-46c4-b48a-87a498ba9131
  * [ ] text-adventure-practice-problem-4                            96f53336-3451-4036-bdc5-ed8589861c37
  * [ ] text-adventure-practice-problem-5                            05d0b9b3-664b-4fdb-9963-370d578fc8c2
  * [ ] text-adventure-practice-problem-6                            a436e51e-1ef4-4d26-b7a0-0a1614462d55
  * [ ] text-adventure-practice-problem-7                            df9a1c97-cde2-416a-a657-71c695aa9034
  * [ ] text-adventure-practice-problem-8                            f470b3fa-7c22-4708-bbb5-d26638e456af
  * [ ] trivia-countdown-practice-problem-1                          f2a2e3f7-e134-4511-b016-c3305774685f
  * [ ] trivia-countdown-practice-problem-2                          e51c4023-8688-43f5-b2c2-2a4ed6843aa6
  * [ ] trivia-countdown-practice-problem-3                          425282bd-0689-4e2c-85b0-fbe051ac405d
  * [ ] trivia-countdown-practice-problem-4                          0016aaef-910a-41e0-98ff-9b1cdc7378a5
  * [ ] trivia-countdown-practice-problem-5                          1eef952d-e9ef-4f9c-9c6d-5bf1d0a7dce1
  * [ ] trivia-countdown-practice-problem-6                          d492103a-8b2a-4d66-ba28-c7943fc0e9b5
  * [ ] trivia-countdown-practice-problem-7                          4f31e8ea-edd5-4ae9-8680-bb56d42994a1
  * [ ] trivia-countdown-practice-problem-8                          e6ac9ffc-f102-4d5f-bed1-30be064a0419
- [ ] data-science-and-ai-assessment                               COURSE=data-science-and-ai-assessment 
  * [ ] course.json
  * [ ] beginning-of-year-assessment                                 c65344a5-a9b1-4730-8155-00c4a81c49c7
- [ ] data-science-and-ai-b                                        COURSE=data-science-and-ai-b 
  * [ ] course.json
  * [ ] bike-share-planning                                          c42faacd-7f4e-4059-bc40-9977ac7e2dcc
  * [ ] build-a-twitter-bot                                          94c66b00-ad08-4a49-8fb0-81b83fe44ada
  * [ ] can-i-take-your-order                                        4978995d-0b28-4358-9e71-ead3a8f22780
  * [ ] code-cipher                                                  7a956cec-8cb6-4b25-a7bd-41a5462e3a2b
  * [ ] collaborative-sentence                                       75d87018-570d-4fc1-bf98-c3b3e44676cb
  * [ ] font-machine                                                 ac251b02-4ad2-4dd4-8175-3e0803635aa0
  * [ ] gabby-the-chatbot                                            029c5d4d-0bde-43db-aeec-56152537ad49
  * [ ] grid-maze                                                    7295cfe7-0376-4a35-b475-589cee347e60
  * [ ] highway-generator                                            e638a6a9-5f9a-4349-a5f4-36770b8226f0
  * [ ] i-owe-what                                                   7c826427-3c42-4326-8db5-5ffd1a709c0c
  * [ ] interactive-story                                            a412ecee-b78e-4ea0-b0c1-c190ea892a72
  * [ ] math-trainer                                                 0c4086fe-8009-4b66-908d-9399c195578c
  * [ ] media-recommender                                            e5a71c79-e289-4aa2-a0d3-a3673520641b
  * [ ] memory-game                                                  12b0db87-ead4-4048-87fd-b545b7ed5100
  * [ ] password-hacker                                              ca3ee33c-b8a9-4799-9404-8fdd23193d02
  * [ ] photo-classifier                                             d1ecf31d-208f-4371-b82b-13a4bf880c14
  * [ ] plagiarism-detector                                          7714173b-5d70-46c8-be51-71b0be6ae61e
  * [ ] quote-collector                                              83fb127a-ef88-441e-a184-91a9ff61f213
  * [ ] special-request                                              3945d408-c6f7-4034-89f4-1af5b13200a1
  * [ ] sports-reporter                                              1400137d-4b85-422d-94d3-83fd7f26df51
  * [ ] superfan                                                     1276c193-0c5e-4f39-8159-983f79b73b85
  * [ ] text-adventure                                               83d97a9a-bd52-42fa-9e7f-61c8c2e02518
  * [ ] the-great-race                                               2ff035f7-7925-41cb-af3a-7304ac1617b3
  * [ ] twin-counties                                                fbfa11fd-a098-420f-a8f4-a8dff4caa989
  * [ ] video-prompter                                               add21caf-2561-415f-99b5-7913e89803f8
  * [ ] wizard-battle                                                6ad9f9f7-2784-48bb-ad42-2a60b27e419e
- [ ] data-science-and-ai-b-practice-problems                      COURSE=data-science-and-ai-b-practice-problems 
  * [ ] course.json
  * [ ] 1.1_interactive-story-practice-problem-1                     2593112b-1c3d-464d-ae14-6703c0e2fe39
  * [ ] 1.1_interactive-story-practice-problem-2                     4e9b47df-393e-4b61-838a-5f28521f009d
  * [ ] 1.1_interactive-story-practice-problem-3                     8fa18523-1f1c-4236-8d80-39b8444c0b4d
  * [ ] 1.1_interactive-story-practice-problem-4                     7f531f85-5825-4873-9284-8e162aeaeee7
  * [ ] 1.1_interactive-story-practice-problem-5                     09628ea3-03e9-4406-8515-eeac1a31b499
  * [ ] 1.1_interactive-story-practice-problem-6                     8e78fb71-be25-4ee3-a4c0-65f98b4e88d1
  * [ ] 1.1_interactive-story-practice-problem-7                     57e467a3-49c9-4f26-93cc-58246a6f02f8
  * [ ] 1.1_interactive-story-practice-problem-8                     26f12d81-aa38-4c56-8b4c-423c76b3cac9
  * [ ] 1.2_code-cipher-practice-problem-1                           eb261fde-6dd1-459a-9e75-718f1d458f1d
  * [ ] 1.2_code-cipher-practice-problem-2                           aeaa84b7-3920-449f-9d8a-52423ad10bc3
  * [ ] 1.2_code-cipher-practice-problem-3                           6add5c3c-3b70-4cd7-af97-733619c82c61
  * [ ] 1.2_code-cipher-practice-problem-4                           8ef3d483-c9e1-4f23-af5a-cd44295a00b9
  * [ ] 1.2_code-cipher-practice-problem-5                           05265d24-9add-4238-b2ff-b009d834f743
  * [ ] 1.2_code-cipher-practice-problem-6                           077d8e8b-4a89-4d2b-892f-8f8c08177059
  * [ ] 1.2_code-cipher-practice-problem-7                           b6f54655-cff0-4b25-a16d-4b87099b2dff
  * [ ] 1.2_code-cipher-practice-problem-8                           36b695be-535f-4c6e-af5e-e4c85bea7e31
  * [ ] 1.3_the-great-race-practice-problem-1                        20fb555e-f572-407a-9616-c857857f7649 (NOT WIRED INTO COURSE)
  * [ ] 1.3_the-great-race-practice-problem-2                        3f0d5977-9279-4749-8b5d-ccc71125df2a (NOT WIRED INTO COURSE)
  * [ ] 1.3_the-great-race-practice-problem-3                        41ae0db5-3a4c-4eae-90bc-f53daee691eb (NOT WIRED INTO COURSE)
  * [ ] 1.3_the-great-race-practice-problem-4                        5b49ef25-14b6-40b3-8ce2-c09177815f79 (NOT WIRED INTO COURSE)
  * [ ] 1.3_the-great-race-practice-problem-5                        15ac803a-6684-4708-b70c-4379be45352f (NOT WIRED INTO COURSE)
  * [ ] 1.3_the-great-race-practice-problem-6                        6300d7c8-1dbe-4559-8009-fc124d7c85af (NOT WIRED INTO COURSE)
  * [ ] 1.3_the-great-race-practice-problem-7                        cccf5f43-661d-4a97-b6af-4dd08b3e6ecd (NOT WIRED INTO COURSE)
  * [ ] 1.3_the-great-race-practice-problem-8                        ff072906-f34d-4781-b098-bec7e94c8739 (NOT WIRED INTO COURSE)
- [ ] hacking-minecraft                                            COURSE=hacking-minecraft 
  * [ ] course.json
  * [ ] ancient-civilization-builder                                 17f9e7e2-8a6a-41e8-a6eb-915cd88dc45b
  * [ ] block-bistro                                                 55e3b350-21e2-4241-980f-05c1fc24067d
  * [ ] correct-or-eject                                             9148375c-5fb3-451a-91f0-aca410b0badf
  * [ ] cursed-maze                                                  8f1ece22-eaa8-4e2b-a5ce-18d7248ffcc2
  * [ ] dj-party                                                     77d5cd2f-6ca6-4466-869b-c5c3430205a3
  * [ ] laboratory-x                                                 ee1f2350-8786-4987-a5ab-35a7c9eadf52
  * [ ] launchpad-parkour                                            62dae5f5-3e79-47a6-b8b5-7015040965d2
  * [ ] music-explorer                                               6d667200-95c2-4651-98fa-0b5945d0f507
  * [ ] pirate-island                                                a303fc4d-0d02-418c-97f2-ea098fb567db
  * [ ] save-the-village                                             7f0f507c-7eae-4ca5-8d1b-16df80a46a77
  * [ ] snowball-fight                                               0bd44ea1-15a7-4660-9258-3fe989781480
  * [ ] superpower-spotlight                                         00a33115-b5cc-4fc5-a12b-f018764f5a86
- [ ] hour-of-code                                                 COURSE=hour-of-code (DO NOT IMPORT INTO DEMO)
  * [ ] course.json
  * [ ] color-illusion-challenge                                     13ccd365-5173-443d-886c-faef86ebb5ac
  * [ ] escape-room-tower-conquest                                   6a20fae3-bd80-4a05-85ac-ed022d4ef4eb
  * [ ] fan-page                                                     0fab8750-c991-474d-8d3b-dc14bd65210a
  * [ ] floor-is-lava                                                c8a8f14d-cdf8-4634-a490-18557f343847
  * [ ] show-and-tell-gallery                                        55c69339-63ad-4be5-a2e8-e54f903a94f1
- [ ] intro-to-vr                                                  COURSE=intro-to-vr (DO NOT IMPORT INTO PRODUCTION)
  * [ ] course.json
  * [ ] my-alien-family                                              be91e31d-2842-44f3-8cfb-a659683d34d0
- [ ] ios-mobile-app-development                                   COURSE=ios-mobile-app-development 
  * [ ] course.json
  * [ ] album-cover-app                                              f557e22d-4390-4198-9084-9f38637c2460
  * [ ] clone-factory-app                                            9d455815-a487-449d-8f23-ce4f2ce7f6e0
  * [ ] elder-helper                                                 c7981fc4-17fe-4ff6-9b5a-df7ebd165a0d
  * [ ] evolution-app                                                a3787506-6020-4308-a367-8eea9d11d13b
  * [ ] fitness-trainer                                              6e6b0053-e4fa-4e73-b447-0d2633163e11
  * [ ] greeting-card-app                                            dc9d640c-9818-43fc-999f-7c541cd6b4dc
  * [ ] haiku-app                                                    afbb309c-21aa-43b2-9dac-e834ae8e87d5
  * [ ] haunted-house-escape-app                                     4e0a33b1-5483-4186-b8ae-634934465e65
  * [ ] id-card-app                                                  c69b4b72-bf3f-431e-a348-0d79e3255ea2
  * [ ] mystery-boxes-app                                            db499812-7878-474e-b4c9-6452fa243826
  * [ ] powerup-game                                                 e4dadc71-3714-44e6-9286-5ddc79d4d912
  * [ ] this-or-that-app                                             0fba3b06-53d8-4ea8-b963-8f0bb84f635e
  * [ ] wanted-app                                                   adcef348-d0b5-48af-98c3-2467d1bc9aec
- [ ] java-fundamentals                                            COURSE=java-fundamentals 
  * [ ] course.json
  * [ ] a-tale-of-two-characters                                     6a5da90b-c848-4ba7-88ae-239016570c19
  * [ ] banner-printer                                               aff32390-d552-43ef-9646-8eb048322046
  * [ ] dice-battle                                                  ca5a69f7-17a3-44ef-a516-f9db3418a4a3
  * [ ] digital-citizenship-and-safety-lab                           1215f3a5-7435-43b6-8048-998b291ef093
  * [ ] disco-dancer                                                 71743206-f06f-4b06-b2da-057d7a8d63eb
  * [ ] dream-trip                                                   183eccff-6505-49ee-8e94-cca982decd74
  * [ ] emoji-shopper                                                fc563954-e940-4b8d-8870-1f1d7cdc83e8
  * [ ] favorite-movie-quotes                                        b7a61500-baf4-4888-8062-63271bfedff2
  * [ ] field-your-team                                              19a15884-ffbe-4036-831b-9d9bacc465fd
  * [ ] guess-my-number                                              80aa96e9-f18f-4f7d-993d-1eb6e08f950f
  * [ ] java-fun-exam-level-1                                        c0be71c9-fba7-40df-9198-40678eb3f6b9
  * [ ] java-fun-exam-level-2                                        c4871f7b-7961-40de-80de-6a4c634cb8f1
  * [ ] math-master                                                  203da17d-86ca-476d-8575-5ee1d3509c2d
  * [ ] money-maker                                                  eb549a80-fa12-49dd-822b-53c2e03a3918
  * [ ] movie-review-generator                                       f74c33ac-87e7-45af-997e-e424abada074
  * [ ] party-planner                                                6f74d056-f26b-42a6-b9df-b16dd9974155
  * [ ] personal-assistant                                           ef1397c5-f2ba-484e-8d49-ef5a73db6284
  * [ ] population-boom                                              66f70665-4297-4939-9251-b213d010943c
  * [ ] raffle-tickets                                               6b4e24d6-de63-4c1f-913f-9e3db91f98a8
  * [ ] school-announcements                                         89b68227-1618-41a4-9d47-49010838dade
  * [ ] social-status                                                b6344dff-e82c-4174-8341-1ca31f473198
  * [ ] super-powers                                                 40e3bc83-b74a-44d6-b19e-307a372441b9
  * [ ] super-snacks                                                 e8416f5c-590b-46f0-b280-871a8ea6b1d9
  * [ ] temporary-tattoo                                             0f520810-8961-49b4-9106-416d409240c7
  * [ ] two-truths-and-a-lie                                         38fade1f-4451-46f6-bf73-6fcdda02559e
  * [ ] word-builder-challenge                                       26416246-0a6c-48bf-afea-74d4f6c54b38
  * [ ] youre-invited                                                a058fb41-7d14-4d6d-b124-810f9c8782dd
- [ ] professional-learning-computer-science-a                     COURSE=professional-learning-computer-science-a 
  * [ ] course.json
  * [ ] about-hello-world-cs                                         c8f70536-2929-40f3-ace4-db430289ec00
  * [ ] assessing-progress                                           d7a700c6-411a-49a6-8371-6183e991bcd0
  * [ ] getting-to-know-you                                          db2eb625-c15e-48cd-a83a-90097cd07ac6
  * [ ] joining-the-ap-community                                     f325c0bc-1a8f-4b68-8abb-50ab767577ac
  * [ ] logging-in                                                   7819864c-b548-42e7-ad9c-053e9c0fe4ad
  * [ ] planning-the-course                                          aff4a98f-9363-46de-aa74-efda5a94e8f2
  * [ ] scoring-projects                                             2ac52a7b-8d29-4c01-b5c2-5ee131b1e3d4
  * [ ] student-rosters                                              0608fc19-227e-489c-b71a-e03f1e4e90b8
  * [ ] teacher-resources                                            a4588035-a291-47d8-99a0-4fa6a8a76aab
  * [ ] teaching-the-course                                          3dde5c3f-63e2-4c74-9cf4-64767def9bf5
  * [ ] technology-requirements                                      4d25858b-d71a-4cb7-af3b-84ad7ee39181
  * [ ] the-importance-of-computer-science                           4ffc86d7-3a2b-4d37-8f38-82eece4b47c1
  * [ ] understanding-the-course                                     91a49a20-8e51-449b-b26c-4c9ed8e4339d
  * [ ] welcome-presentation                                         2f05fbfa-72d2-44a4-aa17-172e3784487d
- [ ] professional-learning-computer-science-principles            COURSE=professional-learning-computer-science-principles 
  * [ ] course.json
  * [ ] about-hello-world-cs                                         4df35cb4-f072-4362-94e3-4622377d13de (NOT WIRED INTO COURSE)
  * [ ] assessing-progress                                           868294b6-7301-4754-84a9-bb6ffa1eccd6 (NOT WIRED INTO COURSE)
  * [ ] beyond-day-1                                                 202ac136-8011-4c59-9796-574e263786c9
  * [ ] course-overview                                              6a2260a5-2b6c-4996-aca0-992f4c5f330b (NOT WIRED INTO COURSE)
  * [ ] day-1-prep                                                   198ab2d3-6e76-4614-8d1c-322d4da932d5
  * [ ] days-1-3                                                     85a32ef4-0d66-4069-a460-56dcde0e1bc5 (NOT WIRED INTO COURSE)
  * [ ] educator-resources                                           0487fa3a-07c2-474e-8572-43d9b90d8c04
  * [ ] getting-to-know-you                                          bdc46ade-0648-4dd0-9658-0d01a57b6b4a (NOT WIRED INTO COURSE)
  * [ ] intro-to-ap-cs-principles                                    136b9607-2480-47e8-98e7-2fa5d9664486
  * [ ] joining-the-ap-community                                     f63d6f41-720b-41dc-a7b7-769b8a55710e (NOT WIRED INTO COURSE)
  * [ ] logging-in                                                   6533b8b8-a31b-4e4b-9b98-1f66b721920c (NOT WIRED INTO COURSE)
  * [ ] planning-the-course                                          44f78a2d-473a-45c8-9ca8-bbe243dc1374 (NOT WIRED INTO COURSE)
  * [ ] scoring-projects                                             03ee46a8-dc4b-4baf-bc56-62bb8f8495ed (NOT WIRED INTO COURSE)
  * [ ] student-rosters                                              c969b2e0-f0f4-45ba-aa63-5b4e1f107b0d (NOT WIRED INTO COURSE)
  * [ ] teacher-resources                                            1ec085ce-71c5-4f45-81ae-e1f58e76eac0 (NOT WIRED INTO COURSE)
  * [ ] teaching-the-course                                          0e25214e-3ed2-4e79-a17c-9dfbd59d02dd (NOT WIRED INTO COURSE)
  * [ ] technology-requirements                                      fdd9313f-0215-4a89-8920-2f4db6531fac (NOT WIRED INTO COURSE)
  * [ ] the-importance-of-computer-science                           89496ad6-59d6-425a-b7ec-ec3d088d9029 (NOT WIRED INTO COURSE)
  * [ ] tutorial-mouse                                               0261c8ac-4907-4f66-a417-a2b403d89ad1 (NOT WIRED INTO COURSE)
  * [ ] tutorial-overview                                            ddbc2ad2-7c63-4089-a468-9d77ae5c1f6b (NOT WIRED INTO COURSE)
  * [ ] tutorial-touchpad                                            92a1175c-f8a5-4ec3-b033-7badfc4e6f97 (NOT WIRED INTO COURSE)
  * [ ] understanding-the-course                                     5a331f45-c52d-40f6-97d2-5c60aea20890
  * [ ] using-headset                                                b2951c29-18c0-4bd0-a82c-48fdee455b6e (NOT WIRED INTO COURSE)
  * [ ] vr-headset                                                   abf06811-f313-4d37-9645-563063ea8ad8 (NOT WIRED INTO COURSE)
  * [ ] vr-tutorial                                                  5cdf06ac-9e5d-411e-ad2b-b25da459a367
  * [ ] why-computer-science                                         2fb386e2-e388-4e55-a110-f54ead2a6a40
- [ ] professional-learning-data-science-and-ai-a                  COURSE=professional-learning-data-science-and-ai-a 
  * [ ] course.json
  * [ ] about-hello-world-cs                                         621c663f-b7b1-4f61-be89-dc938161d7cb (NOT WIRED INTO COURSE)
  * [ ] beyond-day-1                                                 a80599c0-7e5d-4255-8010-cf0ac5fee5d4
  * [ ] course-answer-key                                            95d6f708-5f78-4832-b705-2251510b1be2 (NOT WIRED INTO COURSE)
  * [ ] course-overview                                              b52608b4-861c-4431-82f5-f5d69788a69c (NOT WIRED INTO COURSE)
  * [ ] day-1-prep                                                   0c940242-bc72-421c-a153-401fd3cee12e
  * [ ] educator-resources                                           b69aefdf-771e-45df-be41-5825bfa3d38a (NOT WIRED INTO COURSE)
  * [ ] getting-to-know-you                                          122ba2c5-8bdb-4392-95b5-56f4d7b4b332 (NOT WIRED INTO COURSE)
  * [ ] intro-to-data-sci-a                                          71ebab2c-d43e-4c97-8707-92fa09817aa0
  * [ ] logging-in                                                   10fdff13-13bd-4638-8b77-24305e9c22b2 (NOT WIRED INTO COURSE)
  * [ ] pacing-guide                                                 266a44e6-c0e5-468c-aa14-71532a22bbae (NOT WIRED INTO COURSE)
  * [ ] project-overview-big-debut                                   0e35c172-f2b7-4a3c-a7f2-10ccc4068b6b (NOT WIRED INTO COURSE)
  * [ ] project-overview-can-i-take-your-order                       ba4c0fd6-f574-4bfe-a452-021408e91429 (NOT WIRED INTO COURSE)
  * [ ] project-overview-fortune-teller                              0815d44b-7144-4645-a052-6757264870de (NOT WIRED INTO COURSE)
  * [ ] project-overview-i-want-it-i-bought-it                       68440af8-593b-4379-a3e6-0e4f63937e9f (NOT WIRED INTO COURSE)
  * [ ] project-overview-interactive-story                           5bd9b2fd-0d6f-43fa-85f1-dfcf6b25de07 (NOT WIRED INTO COURSE)
  * [ ] project-overview-movie-trailer                               feb3d7e5-e680-431d-8bff-642a6a0f6ac2 (NOT WIRED INTO COURSE)
  * [ ] project-overview-number-trick                                3b6d8a07-7553-4e6a-acad-77290f686b1f (NOT WIRED INTO COURSE)
  * [ ] project-overview-speaking-style                              c18a334b-e557-4b88-9df6-6574422d69f6 (NOT WIRED INTO COURSE)
  * [ ] project-overview-sports-reporter                             7e9bd577-a104-44b5-9325-b8edc729b188 (NOT WIRED INTO COURSE)
  * [ ] project-overview-the-goat                                    34676c23-967d-430f-a894-ad21f7b339d3 (NOT WIRED INTO COURSE)
  * [ ] project-overview-the-great-race                              464adc37-3ed6-40fd-a297-8e922c449734 (NOT WIRED INTO COURSE)
  * [ ] project-overview-user-namer                                  3cb48b10-3ed1-4c1a-b09d-b61c6f16ddc1 (NOT WIRED INTO COURSE)
  * [ ] scoring-projects                                             5052e1cf-f12d-4f56-b92d-356fd39da5a6 (NOT WIRED INTO COURSE)
  * [ ] student-rosters                                              9bc30376-76fd-4ca2-8224-43a7d51f3f7d (NOT WIRED INTO COURSE)
  * [ ] technology-requirements                                      609d9c57-5838-42c8-9024-7b7a27f603d4 (NOT WIRED INTO COURSE)
  * [ ] the-importance-of-computer-science                           a0d80bbb-777e-4876-87d6-0aa44676a130 (NOT WIRED INTO COURSE)
  * [ ] vr-tutorial                                                  cde9b1c2-ac9f-40ec-9696-27842613e70f
  * [ ] welcome-presentation                                         cb2d984c-5d41-4837-b4ef-0c0be0167931 (NOT WIRED INTO COURSE)
  * [ ] why-computer-science                                         96423afe-b077-4d7d-8b72-902f4a6c1246
- [ ] professional-learning-data-science-and-ai-b                  COURSE=professional-learning-data-science-and-ai-b 
  * [ ] course.json
  * [ ] beyond-day-1                                                 033bc46e-da7b-4606-ad69-007530312280
  * [ ] day-1-prep                                                   45308739-342a-45ca-bf39-ddfda832c20d
  * [ ] educator-resources                                           e284ecb4-e882-470a-8d2e-fa61f051da03 (NOT WIRED INTO COURSE)
  * [ ] interactive-story-intro                                      f32f2ee9-9904-42b8-86c7-7cba4678a046
  * [ ] intro-to-data-sci-b                                          281b4458-80d6-4a54-a5bd-9e6018e37d7e
  * [ ] why-computer-science                                         6e06af9f-3fe4-44d3-841f-5e86b07440e3
- [ ] professional-learning-hacking-minecraft                      COURSE=professional-learning-hacking-minecraft 
  * [ ] course.json
- [ ] professional-learning-ios-mobile-app-development             COURSE=professional-learning-ios-mobile-app-development 
  * [ ] course.json
- [ ] professional-learning-java-fundamentals                      COURSE=professional-learning-java-fundamentals 
  * [ ] course.json
  * [ ] beyond-day-1                                                 d6c49d5c-ea82-4c2f-aaa8-10e14a9fe896
  * [ ] day-1-prep                                                   edd7bf9a-e50f-4192-a6d8-9e4ad2e5b4f1
  * [ ] educator-resources                                           29a71e12-b58b-46d0-a701-b545474c8bbd (NOT WIRED INTO COURSE)
  * [ ] fav-movie-quotes                                             ff0b0d89-e354-4d14-9434-9fe362dc7f87
  * [ ] intro-to-java-fun                                            9ca0316d-a0ff-4295-9c90-e3566416e4a4
  * [ ] why-computer-science                                         5f2a9b64-3ac2-4529-bb17-ab30be351bf4
- [ ] professional-learning-virtual-reality-a                      COURSE=professional-learning-virtual-reality-a 
  * [ ] course.json
  * [ ] beyond-day-1                                                 a2fe1fd5-08c3-45c6-9a44-dcca00a5a63b
  * [ ] day-1-prep                                                   e50effe9-0d97-4c35-a9e4-65bf1cb9e885
  * [ ] educator-resources                                           51a45641-8112-4bf9-8290-f82a953b6bc9
  * [ ] intro-to-virtual-reality-course-a                            f3e86dc7-b877-49e0-949d-f9b7d9903522
  * [ ] vr-headset                                                   8a9d71ab-d39e-43eb-af74-ebaa67377c63 (NOT WIRED INTO COURSE)
  * [ ] vr-tutorial                                                  06113cae-71aa-4c85-a427-e750bcd5dc18
  * [ ] why-computer-science                                         221c315f-f0ba-43b5-94ab-d86a37545a9c
- [ ] professional-learning-virtual-reality-b                      COURSE=professional-learning-virtual-reality-b 
  * [ ] course.json
  * [ ] about-hello-world-cs                                         c8740384-c9a6-4b70-b226-7f972a30f23f (NOT WIRED INTO COURSE)
  * [ ] beyond-day-1                                                 054698d8-24e1-49c8-a0bf-df71e5c43c4b
  * [ ] course-answer-key                                            38b7069a-a482-48d4-9278-1a80628041d8 (NOT WIRED INTO COURSE)
  * [ ] course-overview                                              e90fae56-87df-487a-aea1-f914163c8791 (NOT WIRED INTO COURSE)
  * [ ] day-1-prep                                                   2837ff5b-e48a-4a81-a4c5-7c16a3c15067
  * [ ] educator-resources                                           d0e182c9-ae38-463d-8b0f-5e36ce64d0b3
  * [ ] getting-to-know-you                                          02726be7-c151-42de-9769-2942469dceaa (NOT WIRED INTO COURSE)
  * [ ] intro-to-virtual-reality-course-b                            893dcd4a-e506-4a32-9e0b-21ca7bc12e90
  * [ ] logging-in                                                   e126d979-65ee-4b48-8c9d-1031c32029ed (NOT WIRED INTO COURSE)
  * [ ] pacing-guide                                                 9c82c8eb-2253-47df-a129-c73fa975003e (NOT WIRED INTO COURSE)
  * [ ] project-overview-cospaces-tutorial                           c6d8e7ab-9895-4a90-b27b-a31772f7e260 (NOT WIRED INTO COURSE)
  * [ ] project-overview-future-me                                   a4064167-4fb7-4729-9344-134fbe91ff6f (NOT WIRED INTO COURSE)
  * [ ] project-overview-level-1-passion-project                     6f5d4573-f10d-44df-b01b-aa9533f022c0 (NOT WIRED INTO COURSE)
  * [ ] project-overview-our-class-pet                               80734255-cb2b-4e09-b280-4057c4425360 (NOT WIRED INTO COURSE)
  * [ ] project-overview-team-battle                                 2de6e532-a351-4a96-b436-5cc0aa4a840f (NOT WIRED INTO COURSE)
  * [ ] scoring-projects                                             60e57d4d-5ab9-4ec0-be7d-3acdb12b80e1 (NOT WIRED INTO COURSE)
  * [ ] student-rosters                                              a5c95949-e2d2-471b-b7b4-bf8a5388d158 (NOT WIRED INTO COURSE)
  * [ ] technology-requirements                                      f7bb1d75-40c3-4d54-8ad9-b33980ffef4c (NOT WIRED INTO COURSE)
  * [ ] the-importance-of-computer-science                           e411beda-ed54-43ca-99bd-af2dedec4701 (NOT WIRED INTO COURSE)
  * [ ] using-a-vr-headset                                           b09ef021-0149-45bd-891e-83476d720a1f (NOT WIRED INTO COURSE)
  * [ ] vr-headset                                                   c00c3114-6e08-4a69-9cdb-214c251ee796 (NOT WIRED INTO COURSE)
  * [ ] vr-tutorial                                                  72da7559-7ba6-4559-8d94-8e6ca9da6405
  * [ ] welcome-presentation                                         1cca59a1-5769-49a3-89ef-2bd17de800c1 (NOT WIRED INTO COURSE)
  * [ ] why-computer-science                                         c1b47da7-050e-4e81-b9fe-019a24676021
- [ ] professional-learning-virtual-reality-c                      COURSE=professional-learning-virtual-reality-c 
  * [ ] course.json
  * [ ] about-hello-world-cs                                         686a75ad-425c-434d-bd5e-f6ee966ee50e (NOT WIRED INTO COURSE)
  * [ ] beyond-day-1                                                 f779a66c-738d-4dfd-82cb-88112611229c
  * [ ] course-answer-key                                            929d94d2-12bc-4886-ae41-cf764c575fd8 (NOT WIRED INTO COURSE)
  * [ ] course-overview-revised                                      6d6513f4-37ec-47d6-b12e-aab37b4d4aaf (NOT WIRED INTO COURSE)
  * [ ] day-1-prep                                                   805f6df7-800b-4c7c-9b6d-8c126ae4cb2a
  * [ ] educator-resources                                           caece51b-d7a4-42b8-a819-e03c1674bda7
  * [ ] intro-to-virtual-reality-course-c                            2a647066-2f18-4969-8ae4-da2747925f5e
  * [ ] logging-in                                                   92a6f791-1064-4158-93fc-86b0dc408074 (NOT WIRED INTO COURSE)
  * [ ] project-overview-giants-on-the-loose                         392252c9-5049-4a50-987b-2a8e6819cf8a (NOT WIRED INTO COURSE)
  * [ ] project-overview-lets-party                                  8db68a0a-1a88-4c68-9278-12d0d387ffd3 (NOT WIRED INTO COURSE)
  * [ ] project-overview-robot-kids                                  f9295862-c0ad-4309-a320-f45319c2faf9 (NOT WIRED INTO COURSE)
  * [ ] scoring-projects                                             da632579-0e57-4520-9a7f-4ca50944e7a2 (NOT WIRED INTO COURSE)
  * [ ] student-rosters                                              6552b9ec-51e8-4d30-afba-044f070ce8d0 (NOT WIRED INTO COURSE)
  * [ ] technology-requirements                                      fb62ea6b-cb96-4570-96f1-2c65a0c44996 (NOT WIRED INTO COURSE)
  * [ ] vr-headset                                                   feec41bb-342c-4b29-bb9f-c550e72836d6 (NOT WIRED INTO COURSE)
  * [ ] vr-tutorial                                                  40b76ecc-cb3c-4f96-9c2e-00e10a1180cb
  * [ ] welcome-presentation                                         0994e705-1075-46e3-a458-cfacde4b7819 (NOT WIRED INTO COURSE)
  * [ ] why-computer-science                                         e85d801b-14f2-40ef-ad6f-0e48beea3391
- [ ] professional-learning-virtual-reality-d                      COURSE=professional-learning-virtual-reality-d 
  * [ ] course.json
  * [ ] about-hello-world-cs                                         97043d4a-7685-4cda-bd69-71368a01baa9 (NOT WIRED INTO COURSE)
  * [ ] beyond-day-1                                                 cb122f2a-6d8f-4c68-b396-5b693c5f4d1b
  * [ ] course-answer-key                                            266bb5a8-6905-47f8-bac8-cc3413442ad0 (NOT WIRED INTO COURSE)
  * [ ] course-overview                                              bdc98c58-350f-4802-aac4-08ff287e0262 (NOT WIRED INTO COURSE)
  * [ ] day-1-prep                                                   97b40e39-5e96-4e12-b7f6-a6599fa8e616
  * [ ] educator-resources                                           31af811e-7349-4bd1-976a-d4caf112cbb3
  * [ ] getting-to-know-you                                          e11cb9b7-1e92-4914-beb6-95ccc45280b9 (NOT WIRED INTO COURSE)
  * [ ] intro-to-virtual-reality-course-d                            3a7e2314-11bb-4de1-8cff-1681a9c02f90
  * [ ] logging-in                                                   4695bf4f-431a-435b-8cb0-bb3e7aaeddad (NOT WIRED INTO COURSE)
  * [ ] pacing-guide                                                 cba574ca-391b-4ee8-8e84-3a12bde07946 (NOT WIRED INTO COURSE)
  * [ ] project-overview-animal-trainer                              e575ec30-505b-4839-91d8-73b0ca20a4a5 (NOT WIRED INTO COURSE)
  * [ ] project-overview-city-builder                                8bc22105-d83c-40e5-b994-9476ddb7c84d (NOT WIRED INTO COURSE)
  * [ ] project-overview-cospaces-tutorial                           28608a1f-53f1-446b-be52-4d60f17ca39f (NOT WIRED INTO COURSE)
  * [ ] project-overview-island-survivors                            f5367e1e-be46-4924-a1b5-9b769a1b7a13 (NOT WIRED INTO COURSE)
  * [ ] project-overview-level-one-passion-project                   21d2483d-e7bb-47cc-8d2c-122a677c72fb (NOT WIRED INTO COURSE)
  * [ ] project-overview-magic-show                                  f8161ef6-b700-4466-b9c4-c768d6a33d6e (NOT WIRED INTO COURSE)
  * [ ] project-overview-scavenger-hunt                              d7a13d9c-eef6-4cfc-a5ca-61c8ba949f99 (NOT WIRED INTO COURSE)
  * [ ] scoring-projects                                             7a80ef74-2acd-4646-bbe9-bc8f382875aa (NOT WIRED INTO COURSE)
  * [ ] student-rosters                                              9e0e4cc9-f586-43f1-82c0-b064e60b5fc7 (NOT WIRED INTO COURSE)
  * [ ] technology-requirements                                      e303cfe1-01c3-438a-b458-41051a42176a (NOT WIRED INTO COURSE)
  * [ ] the-importance-of-computer-science                           174c388c-3960-4bf9-bf94-fa43d3d76ffc (NOT WIRED INTO COURSE)
  * [ ] using-a-vr-headset                                           f93e4d3c-15a4-4a7f-bd81-a20833dbc869 (NOT WIRED INTO COURSE)
  * [ ] vr-headset                                                   be1638fc-a725-4130-bff5-b75d99799755 (NOT WIRED INTO COURSE)
  * [ ] vr-tutorial                                                  e681de56-6358-4ea9-9205-7dd5576073ef
  * [ ] welcome-presentation                                         96ccc101-105e-4b33-8b18-0a8e1a4ff4fa (NOT WIRED INTO COURSE)
  * [ ] why-computer-science                                         9f571ee1-9345-42cb-a50f-ebf3a1cf4693
- [ ] professional-learning-web-development-a                      COURSE=professional-learning-web-development-a 
  * [ ] course.json
  * [ ] about-hello-world-cs                                         dd50431c-207b-4bed-be90-e9e2b5713626 (NOT WIRED INTO COURSE)
  * [ ] beyond-day-1                                                 fdaddd06-7c54-4343-a712-edd4227376bf
  * [ ] course-answer-key                                            d370024a-3c04-46d2-8c9f-1db48bb5232e (NOT WIRED INTO COURSE)
  * [ ] course-overview                                              59c5bb36-9793-467e-86a1-54d5f431b198 (NOT WIRED INTO COURSE)
  * [ ] day-1-prep                                                   5abd105b-2e33-42b2-b811-ee2812107810
  * [ ] getting-to-know-you                                          81ca89ef-ae44-4063-9ba1-bc3adbc1c1b8 (NOT WIRED INTO COURSE)
  * [ ] im-hungry                                                    c88547b1-fab7-4309-826c-a653dcf59cc5
  * [ ] intro-to-web-dev                                             e561429f-7847-424a-9d44-0537b3a0a307
  * [ ] logging-in                                                   232f22a3-8362-4ffd-b775-36b13a512a8b (NOT WIRED INTO COURSE)
  * [ ] pacing-guide                                                 81501de2-c1c2-4160-8295-f5043c359c21 (NOT WIRED INTO COURSE)
  * [ ] project-overview-cheer-up                                    bc3c5f05-4355-4d45-af1f-517a550177f0 (NOT WIRED INTO COURSE)
  * [ ] project-overview-endangered-species                          d7f94fcf-53db-4416-832e-b47779190314 (NOT WIRED INTO COURSE)
  * [ ] project-overview-fan-review                                  d178a13d-9ec2-4d9d-983c-03717341cb20 (NOT WIRED INTO COURSE)
  * [ ] project-overview-im-hungry                                   2a94f4ec-013e-4bc2-9b27-d5dc40f869b4 (NOT WIRED INTO COURSE)
  * [ ] project-overview-optical-illusions                           73ecd8d7-a4a7-41a3-9db6-df53c20451d7 (NOT WIRED INTO COURSE)
  * [ ] project-overview-passion-project-level-one                   1d477033-227c-4e9a-a489-238b3976d08e (NOT WIRED INTO COURSE)
  * [ ] project-overview-passion-project-level-two                   3bce7b51-b629-4bd9-b252-cc001792d57f (NOT WIRED INTO COURSE)
  * [ ] project-overview-playlist-creator                            4105aa5f-71e6-4538-b7bc-c38b0bc31d3b (NOT WIRED INTO COURSE)
  * [ ] project-overview-restaurant-menu                             774d8434-0970-4491-bba1-70cc4b0d1478 (NOT WIRED INTO COURSE)
  * [ ] project-overview-shopping-spree                              aa1c642a-d467-4afb-bced-b6898f11005b (NOT WIRED INTO COURSE)
  * [ ] project-overview-this-or-that                                007c6418-d646-462a-96a9-82c0cffa3482 (NOT WIRED INTO COURSE)
  * [ ] project-overview-two-truths-one-lie                          622dc9e6-0ce9-468f-b7ae-df1f5279a596 (NOT WIRED INTO COURSE)
  * [ ] scoring-projects                                             533b9f9b-7aed-463a-bb96-b10bb6f3d6a8 (NOT WIRED INTO COURSE)
  * [ ] student-rosters                                              4ddb69a7-f4c7-41d8-a410-99e3247ff98b (NOT WIRED INTO COURSE)
  * [ ] technology-requirements                                      a9607a88-3a29-4412-bc32-d878694beb3d (NOT WIRED INTO COURSE)
  * [ ] welcome-presentation                                         eea25715-37eb-48b2-88b4-2fa27c192fab (NOT WIRED INTO COURSE)
  * [ ] why-computer-science                                         9dd8e977-a05a-47f9-ba0b-d17d09e2090e
- [ ] virtual-reality-a                                            COURSE=virtual-reality-a 
  * [ ] course.json
  * [ ] alien-planet                                                 8fd4d8e9-c254-4b1b-b5c2-c6bed2dd9456
  * [ ] alphabet-town                                                21d5c6ae-81a9-44a4-98ce-3ac2f8235b53
  * [ ] animal-rescue                                                7e8a3b4a-508f-4de7-b2cb-1786df3cc3ee
  * [ ] backyard-dance-party                                         4aef6516-397e-4a88-90cd-2e32f9b8866f
  * [ ] dinosaur-hero                                                b278166a-4c3e-4e5f-a937-e07b5faf3f5e
  * [ ] dinosaur-safari                                              b0e017ef-a5b0-4e1a-a787-d251c11f3567
  * [ ] find-the-fish                                                2ed1cc81-02bb-4884-9701-ccc82617e2dd
  * [ ] halloween-parade                                             7cead54f-5420-4d8d-8b2e-5aae4946e393
  * [ ] holiday-fun                                                  736d4120-773e-4f8d-9644-3ddeff89f79b
  * [ ] i-spy                                                        89fe0220-34b9-4686-8fe0-e3d064f8b87f
  * [ ] magic-forest                                                 d109285d-fdfe-41b5-b323-576bff55e616
  * [ ] mail-grab                                                    0f8332ee-7e4b-4243-bc7a-2cbb5a27fcb0
  * [ ] passion-project-level-4                                      1cec0714-8319-42de-87c8-d0cba6b34d0c
  * [ ] passion-project-level-5                                      3e17111c-7c23-46ff-801d-d2d2c4dd9272
  * [ ] picnic-party                                                 a407e119-1b97-4fc6-bf44-a543c24768d8
- [ ] virtual-reality-b                                            COURSE=virtual-reality-b 
  * [ ] course.json
  * [ ] alien-invasion                                               6922c492-13ca-4657-8c20-7db8f062c1dd
  * [ ] animal-whisperer                                             566ddb57-a9fe-487c-85f0-b22302b0cca2
  * [ ] choose-your-destiny                                          2f697c1f-0e38-4b02-b7cd-0968796290f4
  * [ ] clicker-garden                                               a8018630-7b9d-4fcb-82c5-6c66f6cf406e
  * [ ] escape-the-maze                                              e70e0375-1d6b-4d24-891a-cf253779fe80
  * [ ] future-me                                                    d1434c80-368d-4b81-ad0c-3f2d4e40d51a
  * [ ] hide-and-seek                                                8e396664-9b30-49a1-8ecc-625b0da9e42d
  * [ ] lost-treasure                                                09f77075-9071-4faf-a585-0fc0eb401ce4
  * [ ] museum-night                                                 2f2ac1ff-e864-418d-a9df-ea2e5915974d
  * [ ] our-class-pet                                                b5c7b26b-f843-465e-a4be-1efddc0ef419
  * [ ] passion-project-level-1                                      80508c62-9cba-4c42-bc1e-abbe4dec00b7
  * [ ] passion-project-level-2                                      3620ba20-54c7-42b3-8a7b-680a183c75e6
  * [ ] passion-project-level-3                                      4977d997-c561-45d7-b134-709abb802a23
  * [ ] passion-project-level-4                                      25996b84-c6bb-425e-bb2d-45aa3e2e1939
  * [ ] scavenger-hunt                                               c6188976-0dd4-4adf-8690-57f5c44b526f
  * [ ] spy-mission                                                  921c639e-a6c4-42cd-bfd9-7b2b4a45f0ef
  * [ ] team-battle                                                  02d811c4-2652-430e-8c43-d251c8084faf
  * [ ] team-exploration                                             906102ca-e6da-410c-a7b6-01e4cf5f9e04
  * [ ] tiny-town                                                    ee3b7906-c880-4a3b-8db4-125f5565eb19
  * [ ] tutorial                                                     1e131eac-88f8-4dc8-af75-19757155a636
- [ ] virtual-reality-b-beginning-of-year-assessment               COURSE=virtual-reality-b-beginning-of-year-assessment 
  * [ ] course.json
  * [ ] beginning-of-year-assessment                                 3cc059e7-0a5b-49a1-8f29-670e92319876
- [ ] virtual-reality-b-eld                                        COURSE=virtual-reality-b-eld 
  * [ ] course.json
  * [ ] alien-invasion                                               870914ea-aeba-42bf-b5c5-8d37a3e75eb2
  * [ ] animal-whisperer                                             736614d4-c161-4f9a-ad61-b1f807a447e1
  * [ ] clicker-garden                                               cc2181e3-852a-4f56-a9a0-b41004f643e0
  * [ ] escape-the-maze                                              030ec29b-cc8a-4c40-9eb2-dd607f3940da
  * [ ] future-me                                                    51beccf4-0736-46fe-aad3-0dddd121c070
  * [ ] hide-and-seek                                                8f323c6c-b67f-4304-9129-78a334b8f023
  * [ ] our-class-pet                                                541fe83e-7d18-4e15-addd-488cefc43eb1
  * [ ] passion-project-level-1                                      34b91bf9-e1a5-4e01-8e00-08a96d63048a
  * [ ] passion-project-level-2                                      46c43f83-52ec-424f-91e2-e86e6bdd0e9a
  * [ ] passion-project-level-3                                      f95cdb9f-7d6b-4d9a-9070-7578af7dcb46
  * [ ] passion-project-level-4                                      0387d329-4e2f-4b66-a45d-144925b4aae2
  * [ ] spy-mission                                                  4d2aaf82-a6c5-42e2-b8ca-0eaf7134a98e
  * [ ] team-battle                                                  516e21d0-f7fc-4151-9126-4408a18d3cac
  * [ ] team-exploration                                             8715941f-608c-476e-8c02-f6786dee9f13
  * [ ] tiny-town                                                    73752e26-084e-4dca-a0db-b92bc3a01a95
  * [ ] tutorial                                                     dc111035-fe2e-4d7a-a646-95f57203dfa0
- [ ] virtual-reality-b-practice-problems                          COURSE=virtual-reality-b-practice-problems 
  * [ ] course.json
  * [ ] 1.1_our-class-pet-practice-problem-1                         eedf5d14-80d9-4fa8-a580-6a5615c7867c
  * [ ] 1.1_our-class-pet-practice-problem-2                         2abb6730-ca42-4b21-ac3a-e57eae063bb6
  * [ ] 1.1_our-class-pet-practice-problem-3                         36f6b4ad-cb8e-459c-8e64-15e485d6afb3
  * [ ] 1.1_our-class-pet-practice-problem-4                         520137ef-22fe-416e-91fb-e1932f8047ca
  * [ ] 1.1_our-class-pet-practice-problem-5                         b5f70e30-8500-4856-b083-27ac8f7e23ba
  * [ ] 1.1_our-class-pet-practice-problem-6                         6e372e4d-3938-4d76-a041-e6a8ccdec4e6
  * [ ] 1.1_our-class-pet-practice-problem-7                         fc0b2a6f-b619-4db4-acb7-19506106e958
  * [ ] 1.1_our-class-pet-practice-problem-8                         46a09c5e-1698-43b3-87df-92c8198f6ee4
  * [ ] 1.2_team-battle-practice-problem-1                           adf25c9e-1479-4b64-94ca-7b7ae026b2e9
  * [ ] 1.2_team-battle-practice-problem-2                           3eeb4181-f49a-4d90-b34d-feeb4d79df82
  * [ ] 1.2_team-battle-practice-problem-3                           716b4a75-b2f9-4d40-8fa2-705207211ab6
  * [ ] 1.2_team-battle-practice-problem-4                           b533ed0f-1a3a-426a-b5fa-d4a431e2aa49
  * [ ] 1.2_team-battle-practice-problem-5                           998e09e0-c870-47d6-aa14-c55ff56d4252
  * [ ] 1.2_team-battle-practice-problem-6                           0f39f77b-4065-4bf4-83f5-43bb8adc1dea
  * [ ] 1.2_team-battle-practice-problem-7                           544fda03-bf6e-42b6-ae02-bf7b6e01e5c5
  * [ ] 1.2_team-battle-practice-problem-8                           bfd2e173-3713-4c51-9217-16a69cabd35a
  * [ ] 1.3_future-me-practice-problem-1                             5d47b825-04ae-448f-98a8-aafda1e40236
  * [ ] 1.3_future-me-practice-problem-2                             e978ccfa-6c3c-4528-8e8c-8ff8deb28b74
  * [ ] 1.3_future-me-practice-problem-3                             c8a1cfff-b861-4324-8f47-f823648fd242
  * [ ] 1.3_future-me-practice-problem-4                             78465887-8837-4bb9-9738-b2a2ea63dc4b
  * [ ] 1.3_future-me-practice-problem-5                             eae43738-0870-4eec-a3a3-18e1151967e3
  * [ ] 1.3_future-me-practice-problem-6                             58c74130-73ef-4ac4-8f4f-50c3ef3f59ca
  * [ ] 1.3_future-me-practice-problem-7                             ef988b23-f00e-4b52-ab1c-220791cbe59f
  * [ ] 1.3_future-me-practice-problem-8                             1f145b40-dd71-4dc8-8a6b-63bed8541047
  * [ ] 2.1_hide-and-seek-practice-problem-1                         ee45c033-be49-477f-8558-63d6422b85fd
  * [ ] 2.1_hide-and-seek-practice-problem-2                         182feec6-cdc8-4b1c-9894-7f9aff4c508b
  * [ ] 2.1_hide-and-seek-practice-problem-3                         128e25d4-35d3-4c8e-854e-1bd4108a1335
  * [ ] 2.1_hide-and-seek-practice-problem-4                         ad183025-3af1-4dba-8d2e-2dfd80e5136d
  * [ ] 2.1_hide-and-seek-practice-problem-5                         ed3bdc51-b649-4965-b36c-44716660544b
  * [ ] 2.1_hide-and-seek-practice-problem-6                         71b01549-d356-4c1d-9f03-4350d9d15027
  * [ ] 2.1_hide-and-seek-practice-problem-7                         0382be86-7421-48aa-8290-1a4f1158b467
  * [ ] 2.1_hide-and-seek-practice-problem-8                         9c499eab-366c-49f7-8b63-b06d1cdebd9f
  * [ ] 2.2_animal-whisperer-practice-problem-1                      fa8ecb5f-2edd-452b-a37b-ae3a13b366ea
  * [ ] 2.2_animal-whisperer-practice-problem-2                      2e66a319-6984-4743-a94c-4d9f34978466
  * [ ] 2.2_animal-whisperer-practice-problem-3                      d945c1e7-5d10-4523-a4bb-bc27f99507bb
  * [ ] 2.2_animal-whisperer-practice-problem-4                      d5796349-40e1-4b4d-b889-5df88d19dbde
  * [ ] 2.2_animal-whisperer-practice-problem-5                      199fba19-dcb1-4fc0-a9d4-0e34d15c1114
  * [ ] 2.2_animal-whisperer-practice-problem-6                      63702fe2-2cf9-4bf8-8bca-784981d1035c
  * [ ] 2.2_animal-whisperer-practice-problem-7                      10c42b71-4c48-4d0a-affe-a483da3a33c8
  * [ ] 2.2_animal-whisperer-practice-problem-8                      5b4469c9-38e0-4c63-92c9-cbeb8a8906ca
  * [ ] 2.3_alien-invasion-practice-problem-1                        017aea8e-f59f-48c4-a727-da9b4e80ed70
  * [ ] 2.3_alien-invasion-practice-problem-2                        f855b0bf-457d-4ee0-8744-d5e1171e7fe0
  * [ ] 2.3_alien-invasion-practice-problem-3                        07795cc3-1261-4bf2-99e1-39985588534d
  * [ ] 2.3_alien-invasion-practice-problem-4                        13310ca6-9d5c-4a4c-ae81-ee370ddf112f
  * [ ] 2.3_alien-invasion-practice-problem-5                        2e06dd81-4c6a-4dc9-b633-a2d62bfb5ddb
  * [ ] 2.3_alien-invasion-practice-problem-6                        ec6e7287-03dd-4318-84d5-c008313300fc
  * [ ] 2.3_alien-invasion-practice-problem-7                        64a722f4-62a1-4597-8599-f35404f970b7
  * [ ] 2.3_alien-invasion-practice-problem-8                        e0f5aabd-5aff-4872-8a8f-1d66797312f3
- [ ] virtual-reality-beginning-of-year-survey                     COURSE=virtual-reality-beginning-of-year-survey 
  * [ ] course.json
  * [ ] beginning-of-year-student-survey                             b54ba091-41e9-4978-9926-be170e91a9c7
- [ ] virtual-reality-c                                            COURSE=virtual-reality-c 
  * [ ] course.json
  * [ ] a-symbiotic-world                                            53b690c0-525d-4ab0-847d-c250f6c5183d
  * [ ] animal-life                                                  afda53ff-5181-41a8-a184-c4521d9606d9
  * [ ] animal-trainer                                               87d09919-3474-4ce7-b494-ed8a3bf68e1d
  * [ ] clicker-garden                                               3e9dceec-3860-11ec-8d3d-0242ac130003
  * [ ] clubhouse                                                    76946eb3-dbaf-4352-86b5-a0c2268fc546
  * [ ] costume-shop                                                 9616b258-86ce-4bda-b8c1-c53bf743eaa4
  * [ ] dream-house                                                  5181bb7c-1fad-46b0-9104-c508781df63b
  * [ ] feeding-frenzy                                               8cf454c4-0986-4545-872f-7ee50cb7bb4c
  * [ ] giants-on-the-loose                                          10ca3a6f-dc76-4037-b8fd-c89be71bbccc
  * [ ] interview-an-innovator                                       86ba3e42-8286-43b2-b3ef-cd7976f0d14f
  * [ ] into-the-tv                                                  acf26774-e4a4-46da-8712-20bcd1f5f505
  * [ ] island-survivors                                             ef221fc1-6854-4e35-ae7a-df458bf2988a
  * [ ] lets-party                                                   b23666be-bc2e-438f-b8dd-93a6fee466a9
  * [ ] musical-forest                                               9fc81f75-fcc3-40be-897b-70027bbf5e17
  * [ ] my-digital-footprint                                         7b5c0ab7-1751-4c38-8aa4-ab1070bd5e94 (NOT WIRED INTO COURSE)
  * [ ] passion-project-level-1                                      3e01f0ee-d728-4330-9daf-7f95507e913e
  * [ ] passion-project-level-2                                      c99b8d21-180f-4adf-a7c5-a32647c5beba
  * [ ] passion-project-level-3                                      2f95b5e4-df98-4987-8787-e400f28cce39
  * [ ] passion-project-level-4                                      b119ee25-e838-49cb-b0eb-e0c9d86a272a
  * [ ] passion-project-team-level-4                                 a6c8b6b9-2760-41dc-b4af-7b0e1a848970
  * [ ] robot-kids                                                   04bb05d4-11fc-46bf-95b9-340d794b7177
  * [ ] say-hello                                                    2941bd58-1a0d-4502-b1cf-26246239ac90 (NOT WIRED INTO COURSE)
  * [ ] scavenger-hunt                                               d5bf29be-708b-496e-90a6-c7d6f941f26a
  * [ ] show-and-tell-room                                           5c371ac0-6ed2-4155-a943-3597bb8db049
  * [ ] spot-the-bot                                                 024188ff-b6e1-401d-9814-198411d5eebc
  * [ ] sunken-treasure                                              61b112ee-3a85-43de-928f-81371a1304a8
  * [ ] time-traveler                                                77d235b2-fa05-4e0c-a3a1-fdc3e9ad6e62
  * [ ] toys-of-wonder                                               b32d588d-16f7-494b-a42d-469bbc0cd01d
  * [ ] tutorial                                                     4d511625-36ca-4f26-a52d-ce6a3f9281a8
- [ ] virtual-reality-c-practice-problems                          COURSE=virtual-reality-c-practice-problems 
  * [ ] course.json
  * [ ] 1.1_giants-on-the-loose-practice-problem-1                   df7004f6-2285-4489-acca-ab1e76205aca
  * [ ] 1.1_giants-on-the-loose-practice-problem-2                   217dd9b6-0013-4f52-8840-65a86bdaa6e1
  * [ ] 1.1_giants-on-the-loose-practice-problem-3                   4bf81148-953b-4423-9420-b4a848683cdd
  * [ ] 1.1_giants-on-the-loose-practice-problem-4                   78ce304c-d8e5-41c8-ac52-5b11377ab381
  * [ ] 1.1_giants-on-the-loose-practice-problem-5                   fd07379f-47c2-4565-bf69-4e35109494f6
  * [ ] 1.1_giants-on-the-loose-practice-problem-6                   e162f2ae-042f-48e1-984c-bb4ba770aa2b
  * [ ] 1.1_giants-on-the-loose-practice-problem-7                   a39b0718-3e0d-40c1-8ff0-dea440132529
  * [ ] 1.1_giants-on-the-loose-practice-problem-8                   019c7807-d25f-49b1-9d44-51650069361e
  * [ ] 1.2_robot-kids-practice-problem-1                            1dbc4783-0ad4-42e3-a2c0-c46221da7fa3
  * [ ] 1.2_robot-kids-practice-problem-2                            2aef9035-0d5e-4431-9111-4dfd28c37e0b
  * [ ] 1.2_robot-kids-practice-problem-3                            e10ed09f-9389-4af5-a498-507bd2d3255c
  * [ ] 1.2_robot-kids-practice-problem-4                            0cb0d11d-9890-4f87-a65b-d5f4d7b0a66c
  * [ ] 1.2_robot-kids-practice-problem-5                            325b5d49-518c-4ba2-8f13-120db632e40c
  * [ ] 1.2_robot-kids-practice-problem-6                            40cc5fdc-7999-4385-aa00-b6cd94e7eaa7
  * [ ] 1.2_robot-kids-practice-problem-7                            df820330-d26a-4dc2-904c-5c3b0d767f6e
  * [ ] 1.2_robot-kids-practice-problem-8                            aabae78c-50b8-4831-9a99-f545a78c5008
  * [ ] 1.3_lets-party-practice-problem-1                            a6978a90-7b02-4065-9de5-afbd829a1a52
  * [ ] 1.3_lets-party-practice-problem-2                            6175c25c-89f8-4aa2-af1b-1b6e28875722
  * [ ] 1.3_lets-party-practice-problem-3                            517717ff-680d-40da-a453-adf379c551e6
  * [ ] 1.3_lets-party-practice-problem-4                            770e3817-ac2f-4868-8c74-165f1819fb85
  * [ ] 1.3_lets-party-practice-problem-5                            a40f214b-6324-4d53-abc7-1373dfd5ab9f
  * [ ] 1.3_lets-party-practice-problem-6                            2f29949f-3113-4f56-846f-3ca5146ad3c2
  * [ ] 1.3_lets-party-practice-problem-7                            22275f7e-3609-4494-808c-e2dc182a0de5
  * [ ] 1.3_lets-party-practice-problem-8                            5fb7267e-7005-4cae-aea8-d8ee0bbd1b09
  * [ ] 1.4_independent-projects-practice-problem-1                  c8059b77-e94f-4aaf-9e64-bfc0fc24c548
  * [ ] 1.4_independent-projects-practice-problem-10                 d723908e-65b0-4b39-bfaa-6f0247ff3bd7
  * [ ] 1.4_independent-projects-practice-problem-11                 2cf4b122-c321-4de8-84ff-50c22ad0a091
  * [ ] 1.4_independent-projects-practice-problem-12                 dbe4b352-4159-4ec9-94ad-d3f1046adbae
  * [ ] 1.4_independent-projects-practice-problem-13                 b5a56a42-007e-457d-b0f8-12cc745051d6
  * [ ] 1.4_independent-projects-practice-problem-14                 b671fb3a-421d-4b11-949c-a7e829200b85
  * [ ] 1.4_independent-projects-practice-problem-15                 978bfb72-ac3c-4066-af36-9ab58f151a6f
  * [ ] 1.4_independent-projects-practice-problem-16                 f8a71cf7-ca46-4b79-bff7-055f318ef281
  * [ ] 1.4_independent-projects-practice-problem-17                 15ecf75a-8c18-4490-b94f-8b19b1173ced
  * [ ] 1.4_independent-projects-practice-problem-18                 9e748619-3fd3-46fe-95a3-01afb2dee884
  * [ ] 1.4_independent-projects-practice-problem-19                 ab637e2b-cbe4-45b0-8f54-1260eb07faeb
  * [ ] 1.4_independent-projects-practice-problem-2                  b70aa0a9-7cd1-45c9-89ab-98e17bc069d7
  * [ ] 1.4_independent-projects-practice-problem-20                 e52555d1-1a04-4948-b23f-1acfd333baf5
  * [ ] 1.4_independent-projects-practice-problem-21                 bb4c234f-dbf4-4a0b-bada-50eee405092c
  * [ ] 1.4_independent-projects-practice-problem-22                 0b1036dd-cf43-4043-8c00-a87b5ee930a3
  * [ ] 1.4_independent-projects-practice-problem-23                 3a5067fb-402e-4709-8533-6607962c5200
  * [ ] 1.4_independent-projects-practice-problem-24                 2578c41a-835d-4d91-9788-7cf3627770bf
  * [ ] 1.4_independent-projects-practice-problem-3                  6738d298-4255-4a60-ae6d-e46815d943dd
  * [ ] 1.4_independent-projects-practice-problem-4                  a95ca7f2-2fbb-42ad-9d4e-03a36d977d4e
  * [ ] 1.4_independent-projects-practice-problem-5                  3bb15832-3565-4356-89fb-f896db5fab07
  * [ ] 1.4_independent-projects-practice-problem-6                  7b5c5e54-99eb-4966-b9c7-57d2c6dcfe21
  * [ ] 1.4_independent-projects-practice-problem-7                  e21507c1-0c0c-4f88-9659-17af1c78ff9a
  * [ ] 1.4_independent-projects-practice-problem-8                  a9accbca-61da-4f82-97f0-6ad1b444ec68
  * [ ] 1.4_independent-projects-practice-problem-9                  21231fef-4a5c-42f2-a5f2-69ae0542f21f
  * [ ] 2.1_show-and-tell-room-practice-problem-1                    25d745fd-ed9d-4f21-b15d-086ac2534055
  * [ ] 2.1_show-and-tell-room-practice-problem-2                    d8734312-19da-46b8-9b10-7c61ba2be1af
  * [ ] 2.1_show-and-tell-room-practice-problem-3                    72ca3f77-4c41-4434-b00f-39bd35d3defb
  * [ ] 2.1_show-and-tell-room-practice-problem-4                    f146cc76-ecb9-4423-b063-37b9c1c92bcd
  * [ ] 2.1_show-and-tell-room-practice-problem-5                    0201451f-44c7-4a9c-83a3-0ecc1a06c666
  * [ ] 2.1_show-and-tell-room-practice-problem-6                    f76b62a7-670a-41e0-855d-302cefe0612d
  * [ ] 2.1_show-and-tell-room-practice-problem-7                    efc0647c-0890-4280-b546-64e936ce24c3
  * [ ] 2.1_show-and-tell-room-practice-problem-8                    3343b787-1d1a-4862-bdca-a1790d223d59
  * [ ] 2.2_animal-trainer-practice-problem-1                        b7aabb85-5e61-4a57-bbdf-e6b6db038d40
  * [ ] 2.2_animal-trainer-practice-problem-2                        002a1f97-5a6c-4cbc-9d0f-12cc4d3f66ef
  * [ ] 2.2_animal-trainer-practice-problem-3                        9405caed-9926-44c8-8b76-a7c8bc940cf5
  * [ ] 2.2_animal-trainer-practice-problem-4                        209429d2-f3cc-438c-bac3-82ce60da8719
  * [ ] 2.2_animal-trainer-practice-problem-5                        3db18aed-7edc-4187-8756-be633697fc29
  * [ ] 2.2_animal-trainer-practice-problem-6                        52bf20a4-4909-4c02-b482-0a7bbd81ff05
  * [ ] 2.2_animal-trainer-practice-problem-7                        4707a929-6cba-451c-a12f-f9f8a940849d
  * [ ] 2.2_animal-trainer-practice-problem-8                        157d8ac2-9d2e-48c8-9425-5a3b2b645143
  * [ ] 2.3_island-survivors-practice-problem-1                      b3260cc3-0f21-4c54-9a16-70b7359e232a
  * [ ] 2.3_island-survivors-practice-problem-2                      0f177e37-11ef-4a0f-b4a3-9b113b61a797
  * [ ] 2.3_island-survivors-practice-problem-3                      17c4278c-94fb-4973-91c1-18cc03b1f346
  * [ ] 2.3_island-survivors-practice-problem-4                      25c14df5-78c3-4c31-b406-71a627be0ab0
  * [ ] 2.3_island-survivors-practice-problem-5                      9dcc13a1-ff74-4a2a-9756-adf6faf307f1
  * [ ] 2.3_island-survivors-practice-problem-6                      0ff57f91-880e-44ae-8aa2-a9a144ab8975
  * [ ] 2.3_island-survivors-practice-problem-7                      e93fc04f-329d-4fcf-b43f-9140e8e841a8
  * [ ] 2.3_island-survivors-practice-problem-8                      bd6a6271-06d0-4109-895e-06d98936f831
  * [ ] 2.4_independent-projects-practice-problem-1                  cdfdce1b-1683-4a57-bc27-7b1104eaa63b
  * [ ] 2.4_independent-projects-practice-problem-10                 8cf3b4fd-0b4c-4a6c-9eec-b8f3f4986df0
  * [ ] 2.4_independent-projects-practice-problem-11                 46f09a71-7972-476a-a405-4c5bb71a6e47
  * [ ] 2.4_independent-projects-practice-problem-12                 f7dd25e7-32d6-4d42-ba4a-b6aac7dda10a
  * [ ] 2.4_independent-projects-practice-problem-13                 8add45f9-809b-479b-98c2-b07cf0c0a3d1
  * [ ] 2.4_independent-projects-practice-problem-14                 149f2fc9-cec3-49e4-9653-41808aff8e04
  * [ ] 2.4_independent-projects-practice-problem-15                 7fe2836a-fc5b-4be3-a432-ed74ff9129a0
  * [ ] 2.4_independent-projects-practice-problem-16                 4eab8f94-0126-4886-8a58-2ae452228055
  * [ ] 2.4_independent-projects-practice-problem-17                 3458da75-ab5b-4dc6-b0cc-47b9b54f66c6
  * [ ] 2.4_independent-projects-practice-problem-18                 3831952c-a5f4-461e-b5cc-938fb9ba4c9f
  * [ ] 2.4_independent-projects-practice-problem-19                 b3964ba4-29ee-4e60-abc3-e3e173b49c3d
  * [ ] 2.4_independent-projects-practice-problem-2                  6738dbf6-5c65-4bbc-aafd-263b91c875b0
  * [ ] 2.4_independent-projects-practice-problem-20                 dabfc8e4-2d00-465f-9333-a95e228a3d40
  * [ ] 2.4_independent-projects-practice-problem-21                 06d4c066-342a-436b-a9fb-f2eb5b5f24ac
  * [ ] 2.4_independent-projects-practice-problem-22                 2478a472-ab08-4df3-9b11-45ba3d619295
  * [ ] 2.4_independent-projects-practice-problem-23                 f52b30ab-24b5-4002-a206-5a7065556c8e
  * [ ] 2.4_independent-projects-practice-problem-24                 a234d00e-11ad-4f83-b901-99dd30b7a008
  * [ ] 2.4_independent-projects-practice-problem-3                  049e482e-95b1-4b20-8329-0e529d43a25e
  * [ ] 2.4_independent-projects-practice-problem-4                  2ceb3bcc-8606-4ab2-abe8-85b02f39696a
  * [ ] 2.4_independent-projects-practice-problem-5                  e00ffc4f-5419-40b3-a7fa-1fba362af955
  * [ ] 2.4_independent-projects-practice-problem-6                  f1d19174-ab82-4d6b-9508-a33612f4183f
  * [ ] 2.4_independent-projects-practice-problem-7                  d77d05b3-11d9-4285-b97a-f5effb9e3795
  * [ ] 2.4_independent-projects-practice-problem-8                  ce6fe174-4917-4e71-a759-6f501c2cb5da
  * [ ] 2.4_independent-projects-practice-problem-9                  752482d8-c9f6-4755-9601-a268e8798e35
  * [ ] 3.1_into-the-tv-practice-problem-1                           4f665c60-2224-4a4e-b3bb-ddfc8f06cf1a
  * [ ] 3.1_into-the-tv-practice-problem-2                           3caa6788-a41c-4c72-ac81-0f8610f49a7d
  * [ ] 3.1_into-the-tv-practice-problem-3                           e87a4aab-c43c-4e8a-8ea3-ebeca61fa955
  * [ ] 3.1_into-the-tv-practice-problem-4                           a196349d-4583-473b-a8de-87c5cf409d47
  * [ ] 3.1_into-the-tv-practice-problem-5                           8b2d5905-94f5-4540-9fe7-f16af4ad7319
  * [ ] 3.1_into-the-tv-practice-problem-6                           b7ed3f82-776b-481d-a341-c3a253f05c60
  * [ ] 3.1_into-the-tv-practice-problem-7                           bb5bbd84-1d16-4f49-aa43-dbf608baad31
  * [ ] 3.1_into-the-tv-practice-problem-8                           1e6f55d1-e642-4fc8-8e67-3a5fad536c92
  * [ ] 3.2_time-traveler-practice-problem-1                         a4bf82ec-5758-4751-b755-5b0c3c29ffb3
  * [ ] 3.2_time-traveler-practice-problem-2                         e2ccbdf1-8db2-4d3c-ac7e-1d15122c06de
  * [ ] 3.2_time-traveler-practice-problem-3                         94588e36-7965-44f8-b239-80fd723aa0b8
  * [ ] 3.2_time-traveler-practice-problem-4                         d9a03a5c-8e28-4d9d-ab25-85f586a241f7
  * [ ] 3.2_time-traveler-practice-problem-5                         1de0ba1a-4906-4968-b36e-9b728e79a3da
  * [ ] 3.2_time-traveler-practice-problem-6                         2ed2a3c8-c162-4ec9-b6ca-57b1cb98369f
  * [ ] 3.2_time-traveler-practice-problem-7                         189189b9-a3f1-4a11-983d-842747a11f56
  * [ ] 3.2_time-traveler-practice-problem-8                         e70036d6-3c96-4aa4-b6e0-6023ffa2dab1
  * [ ] clubhouse-practice-problem-1                                 dd1129e7-b2f7-4578-92c6-6f7e2cdf3204
  * [ ] clubhouse-practice-problem-2                                 6de4c16b-333f-4091-bd9a-400ab66588d1
  * [ ] clubhouse-practice-problem-3                                 83355f17-83fa-4429-956d-0ccee119f1d4
  * [ ] clubhouse-practice-problem-4                                 122f4352-7666-48cd-8bad-892b682feb71
  * [ ] clubhouse-practice-problem-5                                 843e5d6b-3f40-4280-b8f7-7b631d0c5a1c
  * [ ] clubhouse-practice-problem-6                                 bfea1ab7-65c8-4d1a-88a6-9f7f35b3ea13
  * [ ] clubhouse-practice-problem-7                                 a88903b9-e81d-4863-9245-b48a4277f427
  * [ ] clubhouse-practice-problem-8                                 fb1d8b58-2985-49e0-b855-fb1ad7abd363
  * [ ] level-3-independent-projects-practice-problem-1              92e389df-2c61-481c-883b-e0a6825f78eb
  * [ ] level-3-independent-projects-practice-problem-10             12e078ee-96d1-419e-b8e4-c6d9302aaf2a
  * [ ] level-3-independent-projects-practice-problem-11             95cd188b-7654-410e-935c-f43cdb12aa19
  * [ ] level-3-independent-projects-practice-problem-12             ef0af9b8-aedb-4a87-8db7-1cf9c406940c
  * [ ] level-3-independent-projects-practice-problem-13             df41f59e-4ea7-498f-8d57-d6b3626974db
  * [ ] level-3-independent-projects-practice-problem-14             687c7615-febb-45b7-aab9-48c77bf5de03
  * [ ] level-3-independent-projects-practice-problem-15             2bb3a4f3-f2c5-4e60-82b1-25e0b3e5998c
  * [ ] level-3-independent-projects-practice-problem-16             2626e0b1-670c-4a6c-b78f-4cbe1bb02de1
  * [ ] level-3-independent-projects-practice-problem-17             e468b56c-e3f1-4ab8-8754-105383cee032
  * [ ] level-3-independent-projects-practice-problem-18             4cd93e65-870e-4dbb-8c12-bc8e44fec98c
  * [ ] level-3-independent-projects-practice-problem-19             56c22a5c-9dfc-4471-a859-f93d932228bc
  * [ ] level-3-independent-projects-practice-problem-2              2b528cf3-632c-431c-bb12-1d80a1619787
  * [ ] level-3-independent-projects-practice-problem-20             57d16a37-7eb3-46fd-ae3d-88385c5d87e4
  * [ ] level-3-independent-projects-practice-problem-21             a9a61f9a-c5c3-4c7d-bd75-c70f6ecec59e
  * [ ] level-3-independent-projects-practice-problem-22             04594434-94c8-4cfc-81c7-a04546c67994
  * [ ] level-3-independent-projects-practice-problem-23             1c277ab1-2a21-42b6-9c9f-44e85b4316ee
  * [ ] level-3-independent-projects-practice-problem-24             1a8ac8db-33b8-46a2-9a86-fce83d6c4734
  * [ ] level-3-independent-projects-practice-problem-3              976eb0bd-9e82-428a-b720-faef7259de06
  * [ ] level-3-independent-projects-practice-problem-4              bda6eb8e-936f-4358-8526-946e2b00be2e
  * [ ] level-3-independent-projects-practice-problem-5              7ae938fe-c324-4d0a-80ba-fa39c33f5911
  * [ ] level-3-independent-projects-practice-problem-6              f3e2bb57-b2e0-47c5-b3d0-2c08b5e5f521
  * [ ] level-3-independent-projects-practice-problem-7              b28c3df6-2250-465f-a389-b6e80224a5ac
  * [ ] level-3-independent-projects-practice-problem-8              56fc76a4-6c2e-493d-b20f-36bd9bd430b2
  * [ ] level-3-independent-projects-practice-problem-9              35d4bb5a-f045-43a6-945e-9a377322303c
- [ ] virtual-reality-d                                            COURSE=virtual-reality-d 
  * [ ] course.json
  * [ ] an-amendment-story                                           76c12d37-6f5d-4cdf-ae48-2c8d2a3c4fff (NOT WIRED INTO COURSE)
  * [ ] animal-trainer                                               089bc6d5-b3cc-4316-89b6-dca5d557a205
  * [ ] choose-your-destiny                                          6a785bb6-a9c8-4213-bd35-b15e9ab4f4d0
  * [ ] city-builder                                                 d1046de0-4a24-4d78-b1b3-bb9abdf1b4d0
  * [ ] complex-contraption                                          7cd05f6b-998d-4358-9426-1bab338718b8
  * [ ] crack-the-case                                               225867a3-bc72-458a-872b-4e74bdde0a6c
  * [ ] dunk-tank-challenge                                          6b71ba0e-85a2-4104-b50a-8c2fa96184e3
  * [ ] final-lap                                                    e41d8249-c1ca-4cc1-beb0-1737467b2e1f
  * [ ] follow-me-friends                                            0d753904-8871-451c-9fc7-c24e3ed4ac9c
  * [ ] gravity-lab                                                  c70379e7-0115-48ed-84f9-6ec8439498a8 (NOT WIRED INTO COURSE)
  * [ ] infinite-runner                                              6bddcc9f-ffb2-4cfd-88b8-3f44a92848f7 (NOT WIRED INTO COURSE)
  * [ ] island-survivors                                             77f63446-e203-4e24-9e0c-0e993b94a529
  * [ ] life-in-the-colony                                           f1a46969-e867-4a2e-bff5-5f81c583099f (NOT WIRED INTO COURSE)
  * [ ] lights-camera-action                                         2e2140ab-8346-459d-a47b-0f7f2ab8974d
  * [ ] magic-show                                                   0308e07b-ca46-49d8-9dc0-92fab09c52ba
  * [ ] music-playlist                                               185c5c4c-a2e5-4dbc-9fe4-5bf8e95dc1ce
  * [ ] natural-disaster-master                                      2f911d7b-08b3-4fd3-a7ba-e63684ef558b (NOT WIRED INTO COURSE)
  * [ ] obstacle-course                                              d08c6681-53ea-4764-aba8-11e151e5ce76
  * [ ] passion-project-level-1                                      01b3816c-7014-448a-98f6-1c405478cefa
  * [ ] passion-project-level-2                                      f9384e44-af26-464e-b5e1-bcd4e292fd84
  * [ ] passion-project-level-3                                      847fd940-b8dc-4959-aee4-118d41371da3
  * [ ] passion-project-level-4                                      5ee70e7d-3119-4ef8-897f-f0b72eecb65b
  * [ ] physics-game                                                 5a29c189-835b-485c-ae27-fe97fd441174
  * [ ] scavenger-hunt                                               ef3fef24-ffab-4f62-a71e-8759246c5fa8
  * [ ] shopping-spree                                               13204192-66e4-4d8b-9166-bafe9788a610 (NOT WIRED INTO COURSE)
  * [ ] solar-system-landing                                         71a18dc5-338b-46e2-825e-b5bd3fafbdc3
  * [ ] the-great-heist                                              aeef289a-4eaa-4aa9-b0e7-740da2c22f69
  * [ ] time-loop                                                    4bd47c9c-9559-415f-98f6-6efa5b175165
  * [ ] time-traveler                                                dfd780cf-bbb8-46c1-955f-019bd9064ba6
  * [ ] tower-conquest                                               49591056-f723-4e8a-bbbe-31f619286ef8
  * [ ] tutorial                                                     81b19b15-e46f-4165-baf8-3b9f53969af9
  * [ ] tv-news-director                                             d95fee62-b9b6-49d7-86ba-148c7b79a711
- [ ] virtual-reality-d-practice-problems                          COURSE=virtual-reality-d-practice-problems 
  * [ ] course.json
  * [ ] 1.1_animal-trainer-practice-problem-1                        6ac55204-4eac-4887-8158-4e84756e9d90
  * [ ] 1.1_animal-trainer-practice-problem-2                        c0a9f51b-efb9-4dc6-b518-1fa185bfbed0
  * [ ] 1.1_animal-trainer-practice-problem-3                        ffa3c401-8ac2-4ddb-9769-930c3740d280
  * [ ] 1.1_animal-trainer-practice-problem-4                        caf30ea2-1a4d-47cb-a787-c476058e4b99
  * [ ] 1.1_animal-trainer-practice-problem-5                        bd09edf9-299a-4b0e-9905-62d16f355110
  * [ ] 1.1_animal-trainer-practice-problem-6                        ca728a7e-7b15-4e57-becc-e3f63a950e14
  * [ ] 1.1_animal-trainer-practice-problem-7                        ab4c07a8-4a83-4513-b649-eb344bfe72c2
  * [ ] 1.1_animal-trainer-practice-problem-8                        7c535bc5-a061-491e-a77a-81dab7d9b17a
  * [ ] 1.2_city-builder-practice-problem-1                          4f89792c-1c7a-4492-a5e8-299a826bfd59
  * [ ] 1.2_city-builder-practice-problem-2                          d174fefd-11c5-47b3-a5ab-eda7acde73f1
  * [ ] 1.2_city-builder-practice-problem-3                          f1928e16-2a2c-481d-90b8-91a38aab0d7d
  * [ ] 1.2_city-builder-practice-problem-4                          894ea48c-5d36-448c-933e-2b364cb0bbf0
  * [ ] 1.2_city-builder-practice-problem-5                          22704e55-b652-414a-b826-da6e71756df0
  * [ ] 1.2_city-builder-practice-problem-6                          8bdbf289-1c35-401d-bfbb-dfd25adb88cb
  * [ ] 1.2_city-builder-practice-problem-7                          ef098071-0a9b-4a4a-8d05-d13d5c2e8bf3
  * [ ] 1.2_city-builder-practice-problem-8                          159e7391-be99-4eca-ace1-978ccd714d27
  * [ ] 1.3_island-survivors-practice-problem-1                      e0cf0008-8c25-4b92-9c1f-6a8d193ccd0e
  * [ ] 1.3_island-survivors-practice-problem-2                      4580f9df-34b5-4504-8c8f-c520c089fef7
  * [ ] 1.3_island-survivors-practice-problem-3                      a5573ade-4a18-47b4-8250-4ea71d83a8cf
  * [ ] 1.3_island-survivors-practice-problem-4                      d8b0a41b-739b-4eea-9beb-47143cd67db1
  * [ ] 1.3_island-survivors-practice-problem-5                      9ce3967a-247a-4266-9e8e-64a21373bd06
  * [ ] 1.3_island-survivors-practice-problem-6                      4052ea73-7785-49e8-91ad-2af20a05b0a0
  * [ ] 1.3_island-survivors-practice-problem-7                      577d70fd-8392-4f56-9e94-3845f8a17638
  * [ ] 1.3_island-survivors-practice-problem-8                      ced79698-d9d2-4fc1-9905-70d8e417c1d6
  * [ ] 1.4_independent-projects-practice-problem-1                  df79d9f3-c67a-437c-be5c-f987bbbd268b
  * [ ] 1.4_independent-projects-practice-problem-10                 621dc5b8-dda8-42b8-9107-cd0dbdb6ae34
  * [ ] 1.4_independent-projects-practice-problem-11                 f4615702-f3c5-4988-8e41-c5d4518b9672
  * [ ] 1.4_independent-projects-practice-problem-12                 5894d754-4e61-45ae-b530-301384df5f4c
  * [ ] 1.4_independent-projects-practice-problem-13                 db816c7a-84e5-403c-9239-f5606e3b1dc0
  * [ ] 1.4_independent-projects-practice-problem-14                 f8311ba4-4f52-44d2-bdce-bb66c0d5dee4
  * [ ] 1.4_independent-projects-practice-problem-15                 b2ad5477-3073-4b6e-ab6e-3ee6a2d342e4
  * [ ] 1.4_independent-projects-practice-problem-16                 097dc891-ab08-4569-b3c9-3a1f5be7bb81
  * [ ] 1.4_independent-projects-practice-problem-17                 7195fb5d-67f0-4098-a380-2107fc023c2f
  * [ ] 1.4_independent-projects-practice-problem-18                 5341cbc9-d8ef-42cb-902c-a7c66ad44de7
  * [ ] 1.4_independent-projects-practice-problem-19                 b8aba492-8dbd-4897-bf10-9ed33cd43f9c
  * [ ] 1.4_independent-projects-practice-problem-2                  c6db82c3-9a11-4c1f-a052-d0b9962e812a
  * [ ] 1.4_independent-projects-practice-problem-20                 72a232dc-0d69-423e-bd24-eb5d47077fa8
  * [ ] 1.4_independent-projects-practice-problem-21                 bf643695-8c49-4d85-b5de-bbe106cdedbf
  * [ ] 1.4_independent-projects-practice-problem-22                 5d0a3473-1d80-462a-bcb8-27b2f17803f9
  * [ ] 1.4_independent-projects-practice-problem-23                 22e7df74-158a-4cb8-9df0-80ea42cc42b8
  * [ ] 1.4_independent-projects-practice-problem-24                 917cc509-c713-4475-bc7e-075af6e25d68
  * [ ] 1.4_independent-projects-practice-problem-3                  c294cc6c-42b2-4fea-b9e4-947925be3617
  * [ ] 1.4_independent-projects-practice-problem-4                  46bef5ef-2a61-42e6-bc75-e32e8f08b4f5
  * [ ] 1.4_independent-projects-practice-problem-5                  f86b7df8-773f-482e-a3d7-4122f7ec9f0a
  * [ ] 1.4_independent-projects-practice-problem-6                  052075d9-343d-409c-99ce-1b1e4ebec379
  * [ ] 1.4_independent-projects-practice-problem-7                  d481aa16-ae5b-443c-857e-418b10f1d267
  * [ ] 1.4_independent-projects-practice-problem-8                  13284ea4-f9aa-488e-90c1-59efac8dda06
  * [ ] 1.4_independent-projects-practice-problem-9                  6a95e15a-66d2-42c5-86a3-5a885b106ec6
  * [ ] 2.1_time-traveler-practice-problem-1                         a268a4be-e802-415f-b15c-70bc4e42fa1d
  * [ ] 2.1_time-traveler-practice-problem-2                         1658ebd2-caf0-49d4-ab6e-0a70d941ee6a
  * [ ] 2.1_time-traveler-practice-problem-3                         332f30a8-1a83-4797-a345-e0638317fb03
  * [ ] 2.1_time-traveler-practice-problem-4                         bd7f7b60-0629-4860-9bec-c3d45ae047a2
  * [ ] 2.1_time-traveler-practice-problem-5                         4f1e4656-990b-4f44-9c38-2f0e97344748
  * [ ] 2.1_time-traveler-practice-problem-6                         f22fae89-bab3-43bc-8299-e8eb992726e8
  * [ ] 2.1_time-traveler-practice-problem-7                         3558780c-aecf-46d0-afa3-a6954f44734b
  * [ ] 2.1_time-traveler-practice-problem-8                         a368c9a9-2103-4b30-bcdc-8b005668447c
  * [ ] 2.2_physics-game-practice-problem-1                          adc1a5e3-e45b-4230-8de1-c7ff75f3f6b0
  * [ ] 2.2_physics-game-practice-problem-2                          ef243191-d533-4a40-ba4c-cef96fdfaa18
  * [ ] 2.2_physics-game-practice-problem-3                          b2e34eaa-e4af-4fc0-b5cc-7c3c8bdba4bb
  * [ ] 2.2_physics-game-practice-problem-4                          6fd74354-ce2c-4812-bd43-156591d692a6
  * [ ] 2.2_physics-game-practice-problem-5                          ff95fcf5-26d9-4fec-a4c8-972ea5ecdbb5
  * [ ] 2.2_physics-game-practice-problem-6                          c8818630-180e-4b13-aad7-7c08fa68ae0d
  * [ ] 2.2_physics-game-practice-problem-7                          54be167b-c26b-493f-919d-377bf1b9ded5
  * [ ] 2.2_physics-game-practice-problem-8                          dd6d0981-9327-449f-9f1b-e04082238806
  * [ ] 2.3_obstacle-course-practice-problem-1                       4707f9b8-56ee-47d5-bbb3-6e6aba16c765
  * [ ] 2.3_obstacle-course-practice-problem-2                       0a9a8ad8-b416-485b-b086-4c90c5064919
  * [ ] 2.3_obstacle-course-practice-problem-3                       06fd347a-1b40-41ad-a450-695d9e5f11dd
  * [ ] 2.3_obstacle-course-practice-problem-4                       74484ae2-e579-4be2-ad55-6e3cc88d4994
  * [ ] 2.3_obstacle-course-practice-problem-5                       d8922640-e0a6-4a1f-a66d-cc075a6967b9
  * [ ] 2.3_obstacle-course-practice-problem-6                       8be20dda-19e5-4ca9-843e-2e2736b41e4b
  * [ ] 2.3_obstacle-course-practice-problem-7                       ec8ef045-355f-4624-94d7-e37d988101b0
  * [ ] 2.3_obstacle-course-practice-problem-8                       3055ce5a-ba64-46ef-bdfc-42693f3a838d
  * [ ] 2.4_independent-projects-practice-problem-1                  76a7cdb7-a356-4420-a3b0-f9ea50864e28
  * [ ] 2.4_independent-projects-practice-problem-10                 fe6e46d7-3e80-4e9e-a1d8-1fe78afe91b2
  * [ ] 2.4_independent-projects-practice-problem-11                 fa12afae-e466-4896-b43e-473d8928b603
  * [ ] 2.4_independent-projects-practice-problem-12                 e465f4ca-a7a9-4835-8b94-ada652c98ca3
  * [ ] 2.4_independent-projects-practice-problem-13                 96d33ee0-815f-4012-9bbf-87c67732e5b6
  * [ ] 2.4_independent-projects-practice-problem-14                 c9bb1ef8-2ebc-4e00-9824-ee864922857d
  * [ ] 2.4_independent-projects-practice-problem-15                 5cb5ef14-dc4f-426e-940f-f36d10d6d8d3
  * [ ] 2.4_independent-projects-practice-problem-16                 8eb01401-d42f-4ae0-9a97-47c71eda2004
  * [ ] 2.4_independent-projects-practice-problem-17                 a9456d39-2c64-4c4f-84c2-945b2d1969e9
  * [ ] 2.4_independent-projects-practice-problem-18                 70ea6b14-af18-4d34-a254-121f6f732988
  * [ ] 2.4_independent-projects-practice-problem-19                 0af03081-0540-4ac5-a25d-3a72d1992449
  * [ ] 2.4_independent-projects-practice-problem-2                  d7d12773-62da-4e14-b982-7fa813987b9d
  * [ ] 2.4_independent-projects-practice-problem-20                 31ac53c4-ccbf-4d51-a321-5500e8cc2c91
  * [ ] 2.4_independent-projects-practice-problem-21                 708d702b-55ff-4a0a-9ef8-ea116095a4fb
  * [ ] 2.4_independent-projects-practice-problem-22                 a78ed782-c6ca-4e4a-91ed-23456293e0a7
  * [ ] 2.4_independent-projects-practice-problem-23                 03ec00ca-4d4a-4dba-917a-ddd1315b6ead
  * [ ] 2.4_independent-projects-practice-problem-24                 a17e10ce-57d0-4baa-9df9-236b9df1c6b0
  * [ ] 2.4_independent-projects-practice-problem-3                  31fe6336-b199-4212-bffc-f87992eb0a57
  * [ ] 2.4_independent-projects-practice-problem-4                  6c72f0b5-ef9f-4866-a280-d9550b0c1882
  * [ ] 2.4_independent-projects-practice-problem-5                  bb125352-167e-4771-8bd5-41ac2f2e0e8a
  * [ ] 2.4_independent-projects-practice-problem-6                  08b0372f-9302-43f1-8126-5b7199467195
  * [ ] 2.4_independent-projects-practice-problem-7                  b895a7ef-77f7-4ce5-aa4b-2baf8ebfcc33
  * [ ] 2.4_independent-projects-practice-problem-8                  36b8a349-ffae-44f2-b6a6-aad93721eef3
  * [ ] 2.4_independent-projects-practice-problem-9                  57e3a9e5-3baa-41ea-873d-879bd426e37a
  * [ ] 3.1_music-playlist-practice-problem-1                        57f65a45-efa0-44b7-9deb-fdd9cb1e37cc
  * [ ] 3.1_music-playlist-practice-problem-2                        3b792be0-a1fa-4386-97ad-e6615b76793d
  * [ ] 3.1_music-playlist-practice-problem-3                        d0331d5c-22c8-4ec9-be2d-154e1d5e4134
  * [ ] 3.1_music-playlist-practice-problem-4                        0743d47c-7b65-4125-a785-df7b996004ee
  * [ ] 3.1_music-playlist-practice-problem-5                        eaa5c439-8139-432f-b12d-ded64592a4bd
  * [ ] 3.1_music-playlist-practice-problem-6                        2eb53bba-777f-4fe1-9452-6cf8a5aaad03
  * [ ] 3.1_music-playlist-practice-problem-7                        27cd4eb7-99a0-45a8-9a5b-4bea6363e3a8
  * [ ] 3.1_music-playlist-practice-problem-8                        251e8aa7-48fa-47a4-9ec7-58e7e77577b9
  * [ ] 3.2_dunk-tank-challenge-practice-problem-1                   d64e921e-1334-4d46-9bac-6ee1d4a2408e
  * [ ] 3.2_dunk-tank-challenge-practice-problem-2                   b192db72-a4b9-4f64-8c41-ffed1125ef41
  * [ ] 3.2_dunk-tank-challenge-practice-problem-3                   00509522-c4dc-457d-ae79-a60bfd25d01c
  * [ ] 3.2_dunk-tank-challenge-practice-problem-4                   096534de-e6b5-4fda-885f-31588266791e
  * [ ] 3.2_dunk-tank-challenge-practice-problem-5                   ca841405-3029-422d-9136-4f5ade773775
  * [ ] 3.2_dunk-tank-challenge-practice-problem-6                   56e9dace-974f-4b56-958f-080679f5b2f5
  * [ ] 3.2_dunk-tank-challenge-practice-problem-7                   180b122c-9eda-4724-acb0-31eed67ee7c4
  * [ ] 3.2_dunk-tank-challenge-practice-problem-8                   f8948419-6b26-4574-971f-13bd228562aa
  * [ ] 3.3_tower-conquest-practice-problem-1                        a76e016b-edd1-4852-877b-8000ec51143f
  * [ ] 3.3_tower-conquest-practice-problem-2                        87372789-0733-4eb6-9422-e635a321431a
  * [ ] 3.3_tower-conquest-practice-problem-3                        b3af2bc4-6232-4afb-9295-fef31b1c82de
  * [ ] 3.3_tower-conquest-practice-problem-4                        98c45257-08c7-44a7-890e-54e64ae1d348
  * [ ] 3.3_tower-conquest-practice-problem-5                        e9530ff5-7c83-423c-8083-498c63ef203c
  * [ ] 3.3_tower-conquest-practice-problem-6                        08107f33-35f8-488b-b2fe-72660bd89b0f
  * [ ] 3.3_tower-conquest-practice-problem-7                        2a2b4c08-66d7-43fb-864f-47085b0ec50b
  * [ ] 3.3_tower-conquest-practice-problem-8                        c98a3583-929d-4a82-bf7c-2d1221828cbd
  * [ ] 3.4_independent-projects-practice-problem-1                  b78eb498-acf5-4d60-8f7b-bba402b23cba
  * [ ] 3.4_independent-projects-practice-problem-10                 ef2bc0c3-4cad-48d7-af1f-b50274885a97
  * [ ] 3.4_independent-projects-practice-problem-11                 f789469e-193a-4d79-8ee6-d9ee6808c64f
  * [ ] 3.4_independent-projects-practice-problem-12                 a61ba037-5e11-424b-9b88-cd43adb9910b
  * [ ] 3.4_independent-projects-practice-problem-13                 efbb5a77-3dcc-4645-af85-59e148bfb926
  * [ ] 3.4_independent-projects-practice-problem-14                 a7e6c25d-6729-4829-8f3f-4a5a65fb244b
  * [ ] 3.4_independent-projects-practice-problem-15                 24b41ec0-6db7-4113-8b40-20997c7a0e27
  * [ ] 3.4_independent-projects-practice-problem-16                 8863a255-878b-4757-ac11-585d4992d2b9
  * [ ] 3.4_independent-projects-practice-problem-17                 bdc56a76-750d-4b2f-b92b-eba27ecfc8d7
  * [ ] 3.4_independent-projects-practice-problem-18                 661dc6f9-0bdc-4b9a-8a07-cc21bfae7a9f
  * [ ] 3.4_independent-projects-practice-problem-19                 ffa5cf16-e019-4da5-bb7d-a49a4bf00be3
  * [ ] 3.4_independent-projects-practice-problem-2                  ff3f5ed9-387f-4339-a16e-8f27a656cada
  * [ ] 3.4_independent-projects-practice-problem-20                 8158b408-2ded-4bbc-a7f2-3f44888f039b
  * [ ] 3.4_independent-projects-practice-problem-21                 043e4757-a82b-4835-873b-e675c8fafd1f
  * [ ] 3.4_independent-projects-practice-problem-22                 ad464f9e-4172-444c-91a9-e198d534167f
  * [ ] 3.4_independent-projects-practice-problem-23                 8e8b3662-4fe4-4850-bc6d-840ccd481d2a
  * [ ] 3.4_independent-projects-practice-problem-24                 e4977e01-24ad-43be-ad8c-2e04a534622f
  * [ ] 3.4_independent-projects-practice-problem-3                  a9f62bf0-8767-4c86-a7b0-6766e15d19d8
  * [ ] 3.4_independent-projects-practice-problem-4                  ab0be671-7a19-4db0-8cfe-e29f8fcc9993
  * [ ] 3.4_independent-projects-practice-problem-5                  3638e4a1-e5cc-4127-84a4-d8c47502ffd5
  * [ ] 3.4_independent-projects-practice-problem-6                  704d077f-b803-4dc6-a393-5c95e5864abb
  * [ ] 3.4_independent-projects-practice-problem-7                  8b11d66a-c2d3-4dab-a8c3-bfd576406e1e
  * [ ] 3.4_independent-projects-practice-problem-8                  5bdf980d-5477-43c6-a478-61889fd05af4
  * [ ] 3.4_independent-projects-practice-problem-9                  bbd5c94a-9f57-4bd5-addd-7be85f67c71d
- [ ] web-development-a                                            COURSE=web-development-a 
  * [ ] course.json
  * [ ] awards-show                                                  1c607042-d1ca-4d2a-98d3-9b82a786b63d
  * [ ] cheer-up                                                     6fffb279-2441-418a-b686-e7f5301a6d09
  * [ ] choose-your-fighter                                          67aa7844-18e0-461f-9c0d-362c7e85e82a
  * [ ] endangered-species                                           8e1c5af5-71d0-4fbf-8961-832379d9b8dc
  * [ ] epic-mission                                                 d8b60a04-4d0b-4bc9-a78b-82674a23cb30
  * [ ] fan-review                                                   6589f729-0876-4bd6-8e5c-0c4aef993ec4
  * [ ] festival-planner                                             fc04d210-bdb9-47e9-a7fc-e83551fac198
  * [ ] im-hungry                                                    156f3137-0b96-4ed8-8b1e-7f5b5aaa4536
  * [ ] meme-museum                                                  ebe18d8d-a968-49f3-9eca-909f31d0fae2
  * [ ] optical-illusions                                            9b74d309-5a50-4a21-b085-efb1bfa18664
  * [ ] passion-project-level-1                                      e9f115c8-cfbb-4adf-b288-7be459875d91
  * [ ] passion-project-level-2                                      5740b05e-23a8-4b03-92e6-f38abc164a46
  * [ ] passion-project-level-3                                      4da54d22-72b3-462b-80d2-6830741d580f
  * [ ] playlist-creator                                             15c2ee0f-a7ea-4fed-a450-107dd594a699
  * [ ] restaurant-menu                                              84dd82fb-3cec-44ea-b217-d862e550ae30
  * [ ] shopping-spree                                               3df94517-fa17-4363-9f24-d28e9f93d587
  * [ ] this-or-that                                                 925440b8-bae6-4fde-a125-75398be6786e
  * [ ] two-truths-one-lie                                           fe8514ea-82ad-4df4-9215-9ddacef55cfe
- [ ] web-development-a-practice-problems                          COURSE=web-development-a-practice-problems 
  * [ ] course.json
  * [ ] 1.1_im-hungry-practice-problem-1                             df395ba5-d1a9-4579-93e9-1a39e3827d84
  * [ ] 1.1_im-hungry-practice-problem-2                             b09eaa5d-531f-4195-b2ff-942bdaf22bc5
  * [ ] 1.1_im-hungry-practice-problem-3                             05daf01a-37b9-4ff1-ba48-983f7d9898fd
  * [ ] 1.1_im-hungry-practice-problem-4                             a77199f9-8a74-45cb-a995-000bfffa04c0
  * [ ] 1.1_im-hungry-practice-problem-5                             ca08e5c5-057a-4e67-bc5e-93c0d6dc0d17
  * [ ] 1.1_im-hungry-practice-problem-6                             a07b098b-ecdb-4d2d-afbc-1634cf3f7c40
  * [ ] 1.1_im-hungry-practice-problem-7                             005378f2-9819-4725-91b8-12da818009bc
  * [ ] 1.1_im-hungry-practice-problem-8                             0b6ba187-a14e-4887-b356-05700dcab512
  * [ ] 1.2_fan-review-practice-problem-1                            b0b8d5d5-67b1-4794-a85c-49fbf8247848
  * [ ] 1.2_fan-review-practice-problem-2                            0e433028-54c4-42c5-9201-7b0c00129dad
  * [ ] 1.2_fan-review-practice-problem-3                            d9967f42-ddf9-40dd-8b3a-3ce18c0e70a1
  * [ ] 1.2_fan-review-practice-problem-4                            3efb3cc6-4384-4759-966a-7b508a110377
  * [ ] 1.2_fan-review-practice-problem-5                            33b2e354-2834-45ee-bcc6-9b86662d1886
  * [ ] 1.2_fan-review-practice-problem-6                            6a14a5b2-9f40-4df0-b3fa-56fa07395e2d
  * [ ] 1.2_fan-review-practice-problem-7                            98ae2e8e-3278-40fa-81d0-02f56b2c4c2d
  * [ ] 1.2_fan-review-practice-problem-8                            35ebf3b0-a862-416a-9df7-fa9087302de1
  * [ ] 1.3_optical-illusions-practice-problem-1                     31765dfa-d5c8-4dfb-b0e8-ce1037b7d99c
  * [ ] 1.3_optical-illusions-practice-problem-2                     1a3ecfaf-a09f-4992-a6f8-93923bcc1885
  * [ ] 1.3_optical-illusions-practice-problem-3                     ff3e22ef-c9d9-4828-80d5-ca42b2226d08
  * [ ] 1.3_optical-illusions-practice-problem-4                     2ccb8ce8-a799-4615-8073-fae612e6326e
  * [ ] 1.3_optical-illusions-practice-problem-5                     6d31356f-bd4b-401e-a329-13e1332150ea
  * [ ] 1.3_optical-illusions-practice-problem-6                     1857614b-5946-4c8e-83f5-5dbde10145ca
  * [ ] 1.3_optical-illusions-practice-problem-7                     6cd7ea45-4f2f-47c3-b89f-c0723fb66c46
  * [ ] 1.3_optical-illusions-practice-problem-8                     0b744503-05b3-49b1-ba34-ae08ffe87e44
  * [ ] 1.4_independent-projects-practice-problem-1                  39fe5b88-ca2d-476c-b890-768f6b014262
  * [ ] 1.4_independent-projects-practice-problem-10                 c8fc0d72-92fa-4c15-b5f4-6d9f4fcc1f35
  * [ ] 1.4_independent-projects-practice-problem-11                 3b326f58-1a43-4c9e-bcbf-39d2b7cb9e14
  * [ ] 1.4_independent-projects-practice-problem-12                 48923d17-7b15-4c3c-93c8-82d9e2f509aa
  * [ ] 1.4_independent-projects-practice-problem-13                 bd6881e4-c525-446b-8ed5-1f21637e7476
  * [ ] 1.4_independent-projects-practice-problem-14                 45aaa3b2-7265-43ef-993c-a6608ea3df56
  * [ ] 1.4_independent-projects-practice-problem-15                 849b0546-40ac-4472-ab18-df19b3c49a57
  * [ ] 1.4_independent-projects-practice-problem-16                 d6f260ab-0462-4d6d-80d8-cf4715820440
  * [ ] 1.4_independent-projects-practice-problem-17                 d2f3d4c0-d360-4e74-b308-863ba9388569
  * [ ] 1.4_independent-projects-practice-problem-18                 2abff73a-496e-40d4-9c1b-2998745e1b3a
  * [ ] 1.4_independent-projects-practice-problem-19                 3aebd3ea-7686-4ab1-a8b9-017e1d520562
  * [ ] 1.4_independent-projects-practice-problem-2                  3e8d74d5-db22-4e12-b98c-c160984d97ed
  * [ ] 1.4_independent-projects-practice-problem-20                 fc5b8522-1773-4487-904d-2a80c1902efe
  * [ ] 1.4_independent-projects-practice-problem-21                 8642feb8-1175-42d4-bff9-c9f3be5b2244
  * [ ] 1.4_independent-projects-practice-problem-22                 7db18110-8dbf-40fe-9231-9ff01857bc9c
  * [ ] 1.4_independent-projects-practice-problem-23                 ce46ee08-c923-42da-bba6-37edfb709d7b
  * [ ] 1.4_independent-projects-practice-problem-24                 54e486ff-2e39-44b6-a2ed-2d5c56741f5e
  * [ ] 1.4_independent-projects-practice-problem-3                  b0d39253-040d-4482-b49d-d0e96a3df80b
  * [ ] 1.4_independent-projects-practice-problem-4                  b6d271cf-0574-43a9-adb1-52c3b9fb67ee
  * [ ] 1.4_independent-projects-practice-problem-5                  0c92eaf6-60ef-451e-838b-d7cc0b1f5254
  * [ ] 1.4_independent-projects-practice-problem-6                  cc398c4d-04d4-4acd-8516-1ea82a3891d9
  * [ ] 1.4_independent-projects-practice-problem-7                  1ab2b3b5-39d0-4550-aa61-f54e98de23b5
  * [ ] 1.4_independent-projects-practice-problem-8                  4d28025c-b848-4bd8-916c-7529ae173943
  * [ ] 1.4_independent-projects-practice-problem-9                  7ff42b99-7213-42a6-a8ee-209ca9978a04
  * [ ] 2.1_shopping-spree-practice-problem-1                        9ee2963e-4ab1-4ea8-9b37-dd2d58d86dec
  * [ ] 2.1_shopping-spree-practice-problem-2                        0e336d4e-86af-415e-bf0c-b3d2669048bc
  * [ ] 2.1_shopping-spree-practice-problem-3                        4c1eabb7-c59d-4b39-b423-aaab38859a5a
  * [ ] 2.1_shopping-spree-practice-problem-4                        51e17fb1-ce69-4bd9-b3e6-fcee2b42192e
  * [ ] 2.1_shopping-spree-practice-problem-5                        4aef5746-23f2-41bf-81f1-78a1ec994363
  * [ ] 2.1_shopping-spree-practice-problem-6                        d4fca06e-62a9-4bb7-9ec5-078d5c4aafea
  * [ ] 2.1_shopping-spree-practice-problem-7                        8ca0ae8c-56cf-4cbd-aa7e-3880615f0eac
  * [ ] 2.1_shopping-spree-practice-problem-8                        d4e7620d-0eed-45a4-9b18-ddd75d387f9a
  * [ ] awards-show-practice-problem-1                               54bcce6e-6807-4d84-8315-320f3acf28ca
  * [ ] awards-show-practice-problem-2                               fe9478ba-a300-40ed-a582-2e3763f2d18f
  * [ ] awards-show-practice-problem-3                               3c351dd1-ccd1-411e-9ff9-21a337ddfc01
  * [ ] awards-show-practice-problem-4                               ae769cbf-ead7-41af-b1ad-13a13405b0f2
  * [ ] awards-show-practice-problem-5                               ddf09ca2-7a37-4695-8a34-f5ba4a19d3ff
  * [ ] awards-show-practice-problem-6                               441d1709-2a29-4606-aa29-d8f5546dc898
  * [ ] awards-show-practice-problem-7                               81f6d8fd-e8af-43a4-8360-107ccc917f55
  * [ ] awards-show-practice-problem-8                               77868297-bdbe-4506-a6f4-1a786e31a6fe
  * [ ] festival-planner-practice-problem-1                          d4df5e1d-0e25-4a07-b846-c041bc58c75a
  * [ ] festival-planner-practice-problem-2                          ce26b6af-6788-420d-b915-0363159869f5
  * [ ] festival-planner-practice-problem-3                          6f6e4dbd-4157-45c4-9d1a-c4d9c01a7e7e
  * [ ] festival-planner-practice-problem-4                          cf0ee01a-6053-4e89-b98c-38a4ccaf99ed
  * [ ] festival-planner-practice-problem-5                          2fd8c59d-f30d-4ac0-8982-61bb01658d2e
  * [ ] festival-planner-practice-problem-6                          a265a474-416b-4041-9964-337378e08100
  * [ ] festival-planner-practice-problem-7                          9b1aa4b8-8f35-4bfa-9950-267e3212de6a
  * [ ] festival-planner-practice-problem-8                          e29b8c33-258a-4220-b3dd-d1ef0138127b
  * [ ] playlist-creator-practice-problem-1                          2062b620-5ddb-4a0a-9817-6af51658c87d
  * [ ] playlist-creator-practice-problem-2                          5626df98-9a81-496f-88fe-55d8bf4f241d
  * [ ] playlist-creator-practice-problem-3                          3b9d4e04-c276-4164-b20f-418304bf9ae8
  * [ ] playlist-creator-practice-problem-4                          9f25096b-200d-4a48-96be-d80a5424545b
  * [ ] playlist-creator-practice-problem-5                          5c4e6d5d-2e96-4f13-ab5b-d69dbc5b6869
  * [ ] playlist-creator-practice-problem-6                          5a4260ff-2987-45fc-bf56-4aa062c5377d
  * [ ] playlist-creator-practice-problem-7                          862ea360-544f-40f6-84d2-b7730cef9dcd
  * [ ] playlist-creator-practice-problem-8                          1fdc4bee-4419-426e-b031-a09db63ae776
  * [ ] restaurant-menu-practice-problem-1                           a9e0d34f-a26a-4783-91ac-2a28d54720b7
  * [ ] restaurant-menu-practice-problem-2                           a908dd04-16ce-4d67-b696-e3ae0249dcde
  * [ ] restaurant-menu-practice-problem-3                           0cfff02f-f070-4282-86dd-fae7a6d69858
  * [ ] restaurant-menu-practice-problem-4                           baf613ef-a5be-40c2-bcdf-8cfd20732863
  * [ ] restaurant-menu-practice-problem-5                           06d50381-cecb-47fe-aac5-704d4dd868e7
  * [ ] restaurant-menu-practice-problem-6                           ba51f181-64bc-4530-8e35-550a5e24d3b7
  * [ ] restaurant-menu-practice-problem-7                           7c0f3679-4184-46f1-92f1-72f3f8f59479
  * [ ] restaurant-menu-practice-problem-8                           754de187-a952-46bb-8256-4dd059beb9dd
